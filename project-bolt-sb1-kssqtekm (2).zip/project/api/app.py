import os
import subprocess
import tempfile
import base64
import json
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from werkzeug.utils import secure_filename
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'gro', 'xtc', 'tpr', 'ndx', 'data', 'lammpstrj', 'prmtop', 'inpcrd', 'rst7', 'nc', 'mdcrd', 'pdb', 'dcd', 'trr'}
MAX_CONTENT_LENGTH = 500 * 1024 * 1024  # 500MB max file size

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Create upload directory if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_info(filepath):
    """Get file information for uploaded trajectory files"""
    filename = os.path.basename(filepath)
    extension = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
    size = os.path.getsize(filepath)
    
    # Determine MD engine based on file extension
    engine = 'gromacs'
    if extension in ['data', 'lammpstrj']:
        engine = 'lammps'
    elif extension in ['prmtop', 'inpcrd', 'rst7', 'nc', 'mdcrd']:
        engine = 'amber'
    
    return {
        'name': filename,
        'type': extension,
        'size': size,
        'engine': engine,
        'path': filepath
    }

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'MDAnalysis Backend'})

@app.route('/upload', methods=['POST'])
def upload_files():
    """Upload trajectory files for analysis"""
    try:
        if 'files' not in request.files:
            return jsonify({'error': 'No files provided'}), 400
        
        files = request.files.getlist('files')
        if not files or all(file.filename == '' for file in files):
            return jsonify({'error': 'No files selected'}), 400
        
        uploaded_files = []
        session_id = str(uuid.uuid4())
        session_folder = os.path.join(UPLOAD_FOLDER, session_id)
        os.makedirs(session_folder, exist_ok=True)
        
        for file in files:
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(session_folder, filename)
                file.save(filepath)
                
                file_info = get_file_info(filepath)
                file_info['session_id'] = session_id
                uploaded_files.append(file_info)
        
        if not uploaded_files:
            return jsonify({'error': 'No valid files uploaded'}), 400
        
        return jsonify({
            'message': f'Successfully uploaded {len(uploaded_files)} files',
            'session_id': session_id,
            'files': uploaded_files
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500

@app.route('/analyze', methods=['POST'])
def run_analysis():
    """Execute MDAnalysis script and return results"""
    try:
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        script = data.get('script', '')
        session_id = data.get('session_id', '')
        query = data.get('query', '')
        
        if not script:
            return jsonify({'error': 'No script provided'}), 400
        
        if not session_id:
            return jsonify({'error': 'No session ID provided'}), 400
        
        session_folder = os.path.join(UPLOAD_FOLDER, session_id)
        if not os.path.exists(session_folder):
            return jsonify({'error': 'Session not found'}), 404
        
        # Create temporary script file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_script:
            temp_script.write(script)
            script_path = temp_script.name
        
        try:
            # Execute the script in the session folder
            result = subprocess.run(
                ['python', script_path],
                cwd=session_folder,
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            # Collect output
            stdout = result.stdout
            stderr = result.stderr
            return_code = result.returncode
            
            # Find generated plot files
            plot_files = []
            for file in os.listdir(session_folder):
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.svg')):
                    plot_path = os.path.join(session_folder, file)
                    try:
                        with open(plot_path, 'rb') as img_file:
                            img_data = base64.b64encode(img_file.read()).decode('utf-8')
                            plot_files.append({
                                'filename': file,
                                'data': img_data,
                                'type': file.split('.')[-1].lower()
                            })
                    except Exception as e:
                        print(f"Error reading plot file {file}: {e}")
            
            # Parse numerical results if available
            results = {
                'success': return_code == 0,
                'stdout': stdout,
                'stderr': stderr,
                'plots': plot_files,
                'query': query,
                'timestamp': datetime.now().isoformat()
            }
            
            # Try to extract numerical data from stdout
            try:
                lines = stdout.split('\n')
                metrics = {}
                for line in lines:
                    if ':' in line and any(char.isdigit() for char in line):
                        parts = line.split(':')
                        if len(parts) == 2:
                            key = parts[0].strip()
                            value_str = parts[1].strip()
                            try:
                                # Try to extract numerical value
                                import re
                                numbers = re.findall(r'-?\d+\.?\d*', value_str)
                                if numbers:
                                    metrics[key] = float(numbers[0])
                            except:
                                pass
                results['metrics'] = metrics
            except:
                results['metrics'] = {}
            
            return jsonify(results), 200
            
        finally:
            # Clean up temporary script file
            try:
                os.unlink(script_path)
            except:
                pass
            
            # Clean up plot files (optional - you might want to keep them)
            for file in os.listdir(session_folder):
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.svg')):
                    try:
                        os.unlink(os.path.join(session_folder, file))
                    except:
                        pass
        
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Script execution timed out'}), 408
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

@app.route('/sessions/<session_id>/files', methods=['GET'])
def list_session_files(session_id):
    """List files in a session"""
    try:
        session_folder = os.path.join(UPLOAD_FOLDER, session_id)
        if not os.path.exists(session_folder):
            return jsonify({'error': 'Session not found'}), 404
        
        files = []
        for filename in os.listdir(session_folder):
            filepath = os.path.join(session_folder, filename)
            if os.path.isfile(filepath):
                file_info = get_file_info(filepath)
                file_info['session_id'] = session_id
                files.append(file_info)
        
        return jsonify({'files': files}), 200
        
    except Exception as e:
        return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

@app.route('/sessions/<session_id>', methods=['DELETE'])
def cleanup_session(session_id):
    """Clean up session files"""
    try:
        session_folder = os.path.join(UPLOAD_FOLDER, session_id)
        if os.path.exists(session_folder):
            import shutil
            shutil.rmtree(session_folder)
        
        return jsonify({'message': 'Session cleaned up successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': f'Cleanup failed: {str(e)}'}), 500

@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': 'File too large'}), 413

@app.errorhandler(500)
def internal_error(e):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    app.run(debug=True)