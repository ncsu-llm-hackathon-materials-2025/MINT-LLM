import React, { useState, useCallback } from 'react';
import { Atom, Brain, BarChart3, FileText, Settings } from 'lucide-react';
import FileUpload from './components/FileUpload';
import ChatInterface from './components/ChatInterface';
import PlotViewer from './components/PlotViewer';
import MolecularViewer from './components/MolecularViewer';
import { TrajectoryFile, AnalysisQuery, PlotData, StructureData, ChatMessage } from './types/md';
import { MDAnalysisService } from './services/mdAnalysis';

function App() {
  const [uploadedFiles, setUploadedFiles] = useState<TrajectoryFile[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [plots, setPlots] = useState<PlotData[]>([]);
  const [structures, setStructures] = useState<StructureData[]>([]);
  const [activeTab, setActiveTab] = useState<'upload' | 'query' | 'results' | 'viewer'>('upload');

  const mdService = MDAnalysisService.getInstance();

  const handleFilesUploaded = useCallback((files: TrajectoryFile[]) => {
    setUploadedFiles(files);
    if (files.some(f => f.status === 'ready') && activeTab === 'upload') {
      setActiveTab('query');
    }
  }, [activeTab]);

  const handleChatMessage = useCallback(async (message: string) => {
    // Add user message
    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}_user`,
      role: 'user',
      content: message,
      timestamp: new Date(),
      type: 'text'
    };
    
    setChatMessages(prev => [...prev, userMessage]);
    setIsProcessing(true);

    try {
      // Get conversation history for context
      const conversationHistory = chatMessages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Get AI response
      const aiResponse = await mdService.chatWithAI(message, conversationHistory);
      
      // Check if this looks like a request for code generation
      const needsScript = message.toLowerCase().includes('plot') || 
                         message.toLowerCase().includes('calculate') ||
                         message.toLowerCase().includes('analyze') ||
                         message.toLowerCase().includes('show');

      let assistantMessage: ChatMessage = {
        id: `msg_${Date.now()}_assistant`,
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
        type: 'text'
      };

      // If it needs a script and we have files, generate and execute
      if (needsScript && uploadedFiles.length > 0) {
        try {
          const script = await mdService.generateScript(message);
          const results = await mdService.executeScript(script);
          
          assistantMessage.data = {
            script,
            plots: results.plots,
            structures: results.structures
          };
          
          // Update global plots and structures for Results tab
          setPlots(prev => [...prev, ...results.plots]);
          setStructures(prev => [...prev, ...results.structures]);
        } catch (scriptError) {
          assistantMessage.content += `\n\nNote: I encountered an issue generating the script: ${scriptError}`;
          assistantMessage.type = 'error';
        }
      } else if (needsScript && uploadedFiles.length === 0) {
        assistantMessage.content += `\n\n⚠️ Please upload trajectory files first to run analysis scripts.`;
      }

      setChatMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: ChatMessage = {
        id: `msg_${Date.now()}_error`,
        role: 'assistant',
        content: `I apologize, but I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        type: 'error'
      };
      setChatMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  }, [uploadedFiles, chatMessages, mdService]);

  const tabItems = [
    { id: 'upload', label: 'Upload Files', icon: FileText, count: uploadedFiles.length },
    { id: 'query', label: 'Analysis Query', icon: Brain },
    { id: 'results', label: 'Results', icon: BarChart3, count: plots.length },
    { id: 'viewer', label: '3D Viewer', icon: Atom }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-700 rounded-lg flex items-center justify-center">
                <Atom className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">MD Analysis Studio</h1>
                <p className="text-sm text-gray-600">AI-Powered Molecular Dynamics Analysis</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabItems.map((tab) => {
              const isActive = activeTab === tab.id;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    isActive
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className={`inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none rounded-full ${
                      isActive ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'upload' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Upload Trajectory Files</h2>
              <p className="text-gray-600 mb-8">
                Upload your molecular dynamics trajectory files from GROMACS, LAMMPS, or AMBER. 
                The system will automatically detect the format and prepare them for analysis.
              </p>
            </div>
            <FileUpload onFilesUploaded={handleFilesUploaded} uploadedFiles={uploadedFiles} />
          </div>
        )}

        {activeTab === 'query' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">AI Analysis Assistant</h2>
              <p className="text-gray-600 mb-8">
                Have a conversation with the AI about your molecular dynamics simulation. 
                Ask questions, request analyses, and get help interpreting your results.
              </p>
            </div>
            <div className="bg-white rounded-lg border border-gray-200 h-[600px]">
              <ChatInterface
                onMessageSend={handleChatMessage}
                messages={chatMessages}
                isProcessing={isProcessing}
                hasApiKey={mdService.isOpenAIAvailable()}
              />
            </div>
          </div>
        )}

        {activeTab === 'results' && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Analysis Results</h2>
                <p className="text-gray-600">
                  Publication-ready plots and analysis results from your conversations and MD simulation data.
                </p>
              </div>
              {plots.length > 0 && (
                <button className="px-4 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors">
                  Export All Results
                </button>
              )}
            </div>
            <PlotViewer plots={plots} />
          </div>
        )}

        {activeTab === 'viewer' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3D Molecular Viewer</h2>
              <p className="text-gray-600 mb-8">
                Interactive 3D visualization of your molecular structures and trajectories.
              </p>
            </div>
            <MolecularViewer
              structureData={structures[0]?.data}
              format={structures[0]?.format}
              frame={structures[0]?.frame}
              totalFrames={structures[0]?.totalFrames}
            />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;