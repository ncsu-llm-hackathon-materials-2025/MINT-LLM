import React, { useEffect, useRef, useState } from 'react';
import { RotateCw, Download, Settings, Maximize2 } from 'lucide-react';

interface MolecularViewerProps {
  structureData?: string;
  format?: 'pdb' | 'gro' | 'mol2';
  frame?: number;
  totalFrames?: number;
}

export default function MolecularViewer({ 
  structureData = '', 
  format = 'pdb', 
  frame = 0, 
  totalFrames = 1 
}: MolecularViewerProps) {
  const viewerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [viewerSettings, setViewerSettings] = useState({
    style: 'cartoon',
    color: 'spectrum',
    background: 'white'
  });

  useEffect(() => {
    if (!viewerRef.current || !structureData) return;

    // Initialize 3Dmol.js viewer
    const initViewer = () => {
      // This would be the actual 3Dmol.js integration
      // For now, we'll create a placeholder visualization
      const viewer = viewerRef.current;
      if (viewer) {
        viewer.innerHTML = `
          <div class="w-full h-full bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 rounded-lg flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-black bg-opacity-20"></div>
            <div class="relative z-10 text-center text-white">
              <div class="w-32 h-32 mx-auto mb-4 relative">
                <div class="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 animate-pulse opacity-70"></div>
                <div class="absolute inset-2 rounded-full bg-gradient-to-r from-purple-400 to-pink-500 animate-pulse delay-150 opacity-60"></div>
                <div class="absolute inset-4 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 animate-pulse delay-300 opacity-50"></div>
                <div class="absolute inset-6 rounded-full bg-gradient-to-r from-green-400 to-blue-500 animate-pulse delay-500 opacity-40"></div>
              </div>
              <p class="text-lg font-semibold">3D Molecular Structure</p>
              <p class="text-sm opacity-80">Frame ${frame + 1} of ${totalFrames}</p>
              <p class="text-xs opacity-60 mt-2">Format: ${format.toUpperCase()}</p>
            </div>
          </div>
        `;
      }
    };

    initViewer();
  }, [structureData, format, frame, totalFrames, viewerSettings]);

  const handleReset = () => {
    // Reset viewer to initial position
    console.log('Resetting viewer position');
  };

  const handleDownload = () => {
    // Download current view as image
    console.log('Downloading molecular structure image');
  };

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div className={`bg-white rounded-lg border border-gray-200 overflow-hidden ${isFullscreen ? 'fixed inset-4 z-50' : ''}`}>
      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
        <div>
          <h3 className="font-medium text-gray-900">Molecular Structure Viewer</h3>
          <p className="text-sm text-gray-600">Interactive 3D visualization</p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={handleReset}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-md transition-colors"
            title="Reset View"
          >
            <RotateCw className="w-4 h-4" />
          </button>
          <button
            onClick={handleDownload}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-md transition-colors"
            title="Download Image"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={handleFullscreen}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-md transition-colors"
            title="Fullscreen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
          <div className="relative">
            <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-md transition-colors">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="relative">
        <div 
          ref={viewerRef}
          className={`${isFullscreen ? 'h-[calc(100vh-200px)]' : 'h-96'} w-full`}
          id="3dmol-viewer"
        />
        
        {totalFrames > 1 && (
          <div className="absolute bottom-4 left-4 right-4 bg-black bg-opacity-50 rounded-lg p-3">
            <div className="flex items-center space-x-3">
              <span className="text-white text-sm font-medium">Frame:</span>
              <input
                type="range"
                min="0"
                max={totalFrames - 1}
                value={frame}
                className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                readOnly
              />
              <span className="text-white text-sm">{frame + 1}/{totalFrames}</span>
            </div>
          </div>
        )}
      </div>

      <div className="px-4 py-3 bg-gray-50 border-t border-gray-200">
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <span className="text-gray-600">Style:</span>
            <select 
              value={viewerSettings.style}
              onChange={(e) => setViewerSettings({...viewerSettings, style: e.target.value})}
              className="px-2 py-1 border border-gray-300 rounded text-gray-700 text-sm"
            >
              <option value="cartoon">Cartoon</option>
              <option value="sphere">Sphere</option>
              <option value="stick">Stick</option>
              <option value="line">Line</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-gray-600">Color:</span>
            <select 
              value={viewerSettings.color}
              onChange={(e) => setViewerSettings({...viewerSettings, color: e.target.value})}
              className="px-2 py-1 border border-gray-300 rounded text-gray-700 text-sm"
            >
              <option value="spectrum">Spectrum</option>
              <option value="element">Element</option>
              <option value="residue">Residue</option>
              <option value="chain">Chain</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}