import React from 'react';
import { PlotData } from '../types/md';
import { LineChart, BarChart3, Download, Settings } from 'lucide-react';

interface PlotViewerProps {
  plots: PlotData[];
  className?: string;
}

export default function PlotViewer({ plots, className = '' }: PlotViewerProps) {
  const renderPlot = (plot: PlotData) => {
    return (
      <div key={plot.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h3 className="font-medium text-gray-900">{plot.title}</h3>
            <p className="text-sm text-gray-600">{plot.type.toUpperCase()} Analysis</p>
          </div>
          <div className="flex items-center space-x-2">
            <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-md transition-colors">
              <Download className="w-4 h-4" />
            </button>
            <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-md transition-colors">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {plot.imageData ? (
            <div className="flex justify-center">
              <img 
                src={plot.imageData} 
                alt={plot.title}
                className="max-w-full h-auto border border-gray-200 rounded"
              />
            </div>
          ) : (
            <div className="flex justify-center items-center h-64 bg-gray-50 border border-gray-200 rounded">
              <p className="text-gray-500">No plot data available</p>
            </div>
          )}

          {plot.imageData && (
            <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
              <div className="bg-blue-50 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <LineChart className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-900">Analysis Type</span>
                </div>
                <p className="text-blue-700">{plot.type.toUpperCase()}</p>
              </div>
              <div className="bg-green-50 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <BarChart3 className="w-4 h-4 text-green-600" />
                  <span className="font-medium text-green-900">Status</span>
                </div>
                <p className="text-green-700">Generated</p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  if (plots.length === 0) {
    return (
      <div className={`bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 p-12 text-center ${className}`}>
        <LineChart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Plots Generated</h3>
        <p className="text-gray-600">Submit an analysis query to generate visualizations</p>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900">Analysis Results</h2>
        <span className="text-sm text-gray-600">{plots.length} plot{plots.length !== 1 ? 's' : ''} generated</span>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {plots.map(renderPlot)}
      </div>
    </div>
  );
}