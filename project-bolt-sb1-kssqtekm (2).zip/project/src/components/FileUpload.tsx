import React, { useCallback, useState } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { TrajectoryFile } from '../types/md';

interface FileUploadProps {
  onFilesUploaded: (files: TrajectoryFile[]) => void;
  uploadedFiles: TrajectoryFile[];
}

export default function FileUpload({ onFilesUploaded, uploadedFiles }: FileUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFiles = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    setUploading(true);
    const newFiles: TrajectoryFile[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const extension = file.name.split('.').pop()?.toLowerCase() as any;
      
      let engine: 'gromacs' | 'lammps' | 'amber' = 'gromacs';
      if (['data', 'lammpstrj'].includes(extension)) engine = 'lammps';
      if (['prmtop', 'inpcrd', 'rst7', 'nc', 'mdcrd'].includes(extension)) engine = 'amber';

      const trajectoryFile: TrajectoryFile = {
        id: `file_${Date.now()}_${i}`,
        name: file.name,
        type: extension,
        size: file.size,
        uploadedAt: new Date(),
        status: 'processing',
        engine
      };

      newFiles.push(trajectoryFile);
    }

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mark files as ready
    newFiles.forEach(file => file.status = 'ready');
    
    onFilesUploaded([...uploadedFiles, ...newFiles]);
    setUploading(false);
  }, [onFilesUploaded, uploadedFiles]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  const getStatusIcon = (status: TrajectoryFile['status']) => {
    switch (status) {
      case 'uploading':
        return <Loader2 className="w-4 h-4 animate-spin text-blue-500" />;
      case 'processing':
        return <Loader2 className="w-4 h-4 animate-spin text-orange-500" />;
      case 'ready':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
    }
  };

  const getEngineColor = (engine: string) => {
    switch (engine) {
      case 'gromacs': return 'bg-blue-100 text-blue-800';
      case 'lammps': return 'bg-green-100 text-green-800';
      case 'amber': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
          dragActive
            ? 'border-blue-400 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400'
        } ${uploading ? 'opacity-50 pointer-events-none' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <div className="text-lg font-medium text-gray-900 mb-2">
          Upload MD Trajectory Files
        </div>
        <p className="text-gray-600 mb-4">
          Drag and drop files here, or click to select
        </p>
        <input
          type="file"
          multiple
          accept=".gro,.xtc,.tpr,.ndx,.data,.lammpstrj,.prmtop,.inpcrd,.rst7,.nc,.mdcrd"
          onChange={(e) => handleFiles(e.target.files)}
          className="hidden"
          id="file-upload"
          disabled={uploading}
        />
        <label
          htmlFor="file-upload"
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors cursor-pointer disabled:opacity-50"
        >
          {uploading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            'Select Files'
          )}
        </label>
        <p className="text-sm text-gray-500 mt-3">
          Supports: GROMACS (.gro, .xtc, .tpr, .ndx), LAMMPS (.data, .lammpstrj), AMBER (.prmtop, .inpcrd, .rst7, .nc, .mdcrd)
        </p>
      </div>

      {uploadedFiles.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Uploaded Files</h3>
          </div>
          <div className="divide-y divide-gray-200">
            {uploadedFiles.map((file) => (
              <div key={file.id} className="px-6 py-4 flex items-center space-x-4">
                <FileText className="w-8 h-8 text-gray-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-3">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {file.name}
                    </p>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getEngineColor(file.engine)}`}>
                      {file.engine.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500">
                    {(file.size / (1024 * 1024)).toFixed(2)} MB • {file.type.toUpperCase()}
                  </p>
                </div>
                <div className="flex items-center">
                  {getStatusIcon(file.status)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}