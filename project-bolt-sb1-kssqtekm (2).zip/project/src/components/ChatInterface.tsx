import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, Code, Play, Copy, Download, AlertCircle, CheckCircle } from 'lucide-react';
import { ChatMessage, PlotData, StructureData } from '../types/md';
import PlotViewer from './PlotViewer';

interface ChatInterfaceProps {
  onMessageSend: (message: string) => Promise<void>;
  messages: ChatMessage[];
  isProcessing: boolean;
  hasApiKey: boolean;
}

export default function ChatInterface({ onMessageSend, messages, isProcessing, hasApiKey }: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isProcessing) {
      await onMessageSend(input.trim());
      setInput('');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const renderMessage = (message: ChatMessage) => {
    const isUser = message.role === 'user';
    
    return (
      <div key={message.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-6`}>
        <div className={`flex max-w-4xl ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start space-x-3`}>
          <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
            isUser ? 'bg-blue-600 ml-3' : 'bg-gray-600 mr-3'
          }`}>
            {isUser ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
          </div>
          
          <div className={`flex-1 ${isUser ? 'text-right' : 'text-left'}`}>
            <div className={`inline-block p-4 rounded-lg ${
              isUser 
                ? 'bg-blue-600 text-white' 
                : message.type === 'error'
                ? 'bg-red-50 border border-red-200 text-red-900'
                : 'bg-white border border-gray-200 text-gray-900'
            }`}>
              {message.type === 'error' && (
                <div className="flex items-center space-x-2 mb-2">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span className="font-medium text-red-900">Error</span>
                </div>
              )}
              
              <div className="whitespace-pre-wrap">{message.content}</div>
              
              {message.data?.script && (
                <div className="mt-4 bg-gray-900 rounded-lg p-4 overflow-x-auto">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Code className="w-4 h-4 text-green-400" />
                      <span className="text-green-400 text-sm font-medium">Generated Python Script</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => copyToClipboard(message.data!.script!)}
                        className="p-1 text-gray-400 hover:text-white transition-colors"
                        title="Copy script"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <pre className="text-green-400 text-sm font-mono whitespace-pre-wrap">
                    {message.data.script}
                  </pre>
                </div>
              )}
            </div>
            
            {message.data?.plots && message.data.plots.length > 0 && (
              <div className="mt-4">
                <PlotViewer plots={message.data.plots} className="bg-white rounded-lg border border-gray-200 p-4" />
              </div>
            )}
            
            <div className="text-xs text-gray-500 mt-2">
              {message.timestamp.toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const exampleQueries = [
    "Plot the RDF between water oxygens and sodium ions",
    "Calculate the RMSD of the protein backbone over time",
    "Show the diffusion coefficient of my solute molecules",
    "Analyze hydrogen bonds between protein and ligand"
  ];

  return (
    <div className="flex flex-col h-full">
      {/* API Status Banner */}
      {!hasApiKey && (
        <div className="bg-orange-50 border-l-4 border-orange-400 p-4 mb-4">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-orange-400 mr-3" />
            <div>
              <p className="text-sm text-orange-700">
                <strong>Mock Mode:</strong> OpenAI API key not detected. Using template-based responses.
                Add your API key to the .env file to enable real AI conversations.
              </p>
            </div>
          </div>
        </div>
      )}

      {hasApiKey && (
        <div className="bg-green-50 border-l-4 border-green-400 p-4 mb-4">
          <div className="flex items-center">
            <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
            <div>
              <p className="text-sm text-green-700">
                <strong>AI Enabled:</strong> Connected to OpenAI GPT-4o for intelligent MD analysis conversations.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-12">
            <Bot className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              AI-Powered MD Analysis Assistant
            </h3>
            <p className="text-gray-600 mb-6">
              Ask me anything about your molecular dynamics simulation. I can generate Python scripts,
              create visualizations, and help interpret your results.
            </p>
            
            <div className="max-w-2xl mx-auto">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Try asking:</h4>
              <div className="grid grid-cols-1 gap-2">
                {exampleQueries.map((query, index) => (
                  <button
                    key={index}
                    onClick={() => !isProcessing && onMessageSend(query)}
                    className="text-left px-4 py-2 bg-gray-50 hover:bg-gray-100 rounded-md text-sm text-gray-700 hover:text-gray-900 transition-colors disabled:opacity-50"
                    disabled={isProcessing}
                  >
                    "{query}"
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            {messages.map(renderMessage)}
            {isProcessing && (
              <div className="flex justify-start mb-6">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                      <span className="text-gray-600">Analyzing your request...</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <div className="border-t border-gray-200 p-4 bg-white">
        <form onSubmit={handleSubmit} className="flex space-x-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me about your MD simulation..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isProcessing}
          />
          <button
            type="submit"
            disabled={!input.trim() || isProcessing}
            className="px-6 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
}