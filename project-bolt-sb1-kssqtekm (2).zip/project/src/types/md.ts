export interface TrajectoryFile {
  id: string;
  name: string;
  type: 'gro' | 'xtc' | 'tpr' | 'ndx' | 'data' | 'lammpstrj' | 'prmtop' | 'inpcrd' | 'rst7' | 'nc' | 'mdcrd';
  size: number;
  uploadedAt: Date;
  status: 'uploading' | 'processing' | 'ready' | 'error';
  engine: 'gromacs' | 'lammps' | 'amber';
}

export interface AnalysisQuery {
  id: string;
  text: string;
  timestamp: Date;
  status: 'processing' | 'ready' | 'error';
  generatedScript?: string;
  editedScript?: string;
  results?: AnalysisResult;
  explanation?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'text' | 'code' | 'plot' | 'error';
  data?: {
    script?: string;
    plots?: PlotData[];
    structures?: StructureData[];
  };
}

export interface AnalysisResult {
  plots: PlotData[];
  structures: StructureData[];
  summary: string;
  metrics: Record<string, number>;
}

export interface PlotData {
  id: string;
  type: 'rdf' | 'rmsd' | 'rmsf' | 'fes' | 'msd' | 'contact' | 'hbond';
  title: string;
  data: {
    x: number[];
    y: number[];
    labels: string[];
  };
  config: {
    xLabel: string;
    yLabel: string;
    color: string;
    style: 'line' | 'scatter' | 'histogram';
  };
  imageData?: string; // Base64 encoded image data
}

export interface StructureData {
  id: string;
  format: 'pdb' | 'gro' | 'mol2';
  data: string;
  frame: number;
  totalFrames: number;
}

export interface ViewerSpec {
  id: string;
  type: 'plot' | '3d' | 'comparison';
  config: Record<string, any>;
  timestamp: Date;
}