interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OpenAIResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
}

export class OpenAIService {
  private apiKey: string;
  private baseUrl = 'https://api.openai.com/v1';

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!this.apiKey) {
      console.warn('OpenAI API key not found. Running in mock mode.');
    }
  }

  isAvailable(): boolean {
    return !!this.apiKey && this.apiKey.trim() !== '';
  }

  async generateMDScript(query: string): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error('OpenAI API key not available');
    }

    const systemPrompt = `You are an expert in molecular dynamics (MD) simulation analysis using Python and MDAnalysis. 
Generate clean, well-commented Python scripts for MD analysis tasks.

Guidelines:
- Use MDAnalysis library for trajectory analysis
- Include proper imports and error handling
- Generate publication-ready matplotlib plots with proper labels
- Add informative print statements for key results
- Use standard file names: 'topology.gro' and 'trajectory.xtc' for GROMACS files
- Include proper units in labels and outputs
- Make plots publication-ready with appropriate styling`;

    const messages: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Generate a Python script using MDAnalysis for this analysis: ${query}` }
    ];

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: messages,
          temperature: 0.3,
          max_tokens: 2000
        })

        
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OpenAI API error: ${errorData.error?.message || 'Unknown error'}`);
      }

      const data: OpenAIResponse = await response.json();
      return data.choices[0]?.message?.content || 'Error: No response generated';
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw new Error(`Failed to generate script: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async chatCompletion(messages: OpenAIMessage[]): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error('OpenAI API key not available');
    }

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: messages,
          temperature: 0.7,
          max_tokens: 2000
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OpenAI API error: ${errorData.error?.message || 'Unknown error'}`);
      }

      const data: OpenAIResponse = await response.json();
      return data.choices[0]?.message?.content || 'Error: No response generated';
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw new Error(`Failed to get chat response: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async explainResults(scriptOutput: string, plotData: any): Promise<string> {
    if (!this.isAvailable()) {
      throw new Error('OpenAI API key not available');
    }

    const systemPrompt = `You are an expert in molecular dynamics simulation analysis. 
Provide clear, scientific explanations of MD analysis results.

Guidelines:
- Explain the physical meaning of the results
- Mention typical values or ranges when relevant
- Suggest what the results indicate about the molecular system
- Keep explanations accessible but scientifically accurate
- Focus on the most important insights`;

    const messages: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Explain these MD analysis results:\n\nScript output: ${scriptOutput}\n\nPlot data summary: ${JSON.stringify(plotData, null, 2)}` }
    ];

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: messages,
          temperature: 0.5,
          max_tokens: 1000
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OpenAI API error: ${errorData.error?.message || 'Unknown error'}`);
      }

      const data: OpenAIResponse = await response.json();
      return data.choices[0]?.message?.content || 'Error: No explanation generated';
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw new Error(`Failed to generate explanation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}