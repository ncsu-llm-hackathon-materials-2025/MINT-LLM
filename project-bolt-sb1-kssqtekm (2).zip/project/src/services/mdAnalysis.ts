import { AnalysisQuery, PlotData, StructureData } from '../types/md';
import { OpenAIService } from './openai';

interface BackendResponse {
  success: boolean;
  stdout: string;
  stderr: string;
  plots: Array<{
    filename: string;
    data: string;
    type: string;
  }>;
  metrics: Record<string, number>;
  query: string;
  timestamp: string;
}

interface UploadResponse {
  message: string;
  session_id: string;
  files: Array<{
    name: string;
    type: string;
    size: number;
    engine: string;
    session_id: string;
  }>;
}

export class MDAnalysisService {
  private static instance: MDAnalysisService;
  private openaiService: OpenAIService;
  private backendUrl: string;
  private currentSessionId: string | null = null;

  constructor() {
    this.openaiService = new OpenAIService();
    this.backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://127.0.0.1:5000';
  }

  static getInstance(): MDAnalysisService {
    if (!MDAnalysisService.instance) {
      MDAnalysisService.instance = new MDAnalysisService();
    }
    return MDAnalysisService.instance;
  }

  isOpenAIAvailable(): boolean {
    return this.openaiService.isAvailable();
  }

  async uploadFiles(files: FileList): Promise<string> {
    const formData = new FormData();
    
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const response = await fetch(`${this.backendUrl}/upload`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Upload failed');
      }

      const data: UploadResponse = await response.json();
      this.currentSessionId = data.session_id;
      return data.session_id;
    } catch (error) {
      console.error('File upload error:', error);
      throw new Error(`Failed to upload files: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  getCurrentSessionId(): string | null {
    return this.currentSessionId;
  }

  async chatWithAI(message: string, conversationHistory: any[] = []): Promise<string> {
    if (!this.openaiService.isAvailable()) {
      // Fallback response for mock mode
      await new Promise(resolve => setTimeout(resolve, 1000));
      return this.generateMockResponse(message);
    }

    const systemPrompt = {
      role: 'system' as const,
      content: `You are an expert molecular dynamics (MD) simulation analyst and Python programmer. You help scientists analyze their MD trajectories using tools like MDAnalysis, MDTraj, and PyTraj.

Your capabilities:
- Generate Python scripts for MD analysis (RDF, RMSD, RMSF, diffusion, hydrogen bonds, etc.)
- Explain simulation results in scientific terms
- Suggest analysis approaches and interpret data
- Provide publication-ready visualization code

Guidelines:
- Be conversational and helpful
- When generating code, use proper MDAnalysis syntax
- Include matplotlib for publication-ready plots
- Explain the physical meaning of results
- Ask clarifying questions when needed
- Use standard file names: 'topology.gro' and 'trajectory.xtc' for GROMACS files`
    };

    const messages = [
      systemPrompt,
      ...conversationHistory,
      { role: 'user' as const, content: message }
    ];

    try {
      return await this.openaiService.chatCompletion(messages);
    } catch (error) {
      console.warn('OpenAI chat failed, using fallback:', error);
      return this.generateMockResponse(message);
    }
  }

  private generateMockResponse(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('rdf')) {
      return `I'll help you calculate the radial distribution function (RDF). This analysis shows how the density of particles varies as a function of distance from a reference particle.

For your RDF analysis, I'll generate a Python script using MDAnalysis that:
1. Loads your trajectory files
2. Defines the atom groups of interest
3. Calculates the RDF with appropriate binning
4. Creates a publication-ready plot

The RDF will show peaks at characteristic distances where particles prefer to be located relative to each other.`;
    } else if (lowerMessage.includes('rmsd')) {
      return `I'll help you calculate the Root Mean Square Deviation (RMSD) to measure structural changes over time.

RMSD analysis will:
1. Align structures to remove translational and rotational motion
2. Calculate deviations from a reference structure
3. Plot RMSD vs time to show stability

This is essential for understanding protein folding, stability, and conformational changes during your simulation.`;
    } else if (lowerMessage.includes('diffusion')) {
      return `I'll help you calculate diffusion coefficients using Mean Square Displacement (MSD) analysis.

The analysis will:
1. Track particle positions over time
2. Calculate MSD for your molecules
3. Fit the linear region to extract diffusion coefficient
4. Convert to standard units (cm²/s)

This tells us how fast molecules move through your system, which is crucial for transport properties.`;
    } else {
      return `I'm here to help with your molecular dynamics analysis! I can assist with:

• **Structural Analysis**: RMSD, RMSF, radius of gyration, secondary structure
• **Dynamic Properties**: Diffusion coefficients, MSD, velocity autocorrelation
• **Intermolecular Interactions**: RDF, hydrogen bonds, contact analysis
• **Visualization**: Publication-ready plots and 3D molecular structures

What specific analysis would you like to perform on your simulation data?`;
    }
  }

  async generateScript(query: string): Promise<string> {
    // Try to use OpenAI API first, fall back to mock generation
    if (this.openaiService.isAvailable()) {
      try {
        return await this.openaiService.generateMDScript(query);
      } catch (error) {
        console.warn('OpenAI API failed, using fallback:', error);
      }
    }

    // Fallback to mock script generation
    await new Promise(resolve => setTimeout(resolve, 1000));
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('rdf') && lowerQuery.includes('water') && lowerQuery.includes('sodium')) {
      return this.generateRDFScript();
    } else if (lowerQuery.includes('rmsd')) {
      return this.generateRMSDScript();
    } else if (lowerQuery.includes('diffusion')) {
      return this.generateDiffusionScript();
    } else if (lowerQuery.includes('hydrogen bond') || lowerQuery.includes('hbond')) {
      return this.generateHBondScript();
    } else if (lowerQuery.includes('radius of gyration') || lowerQuery.includes('gyration')) {
      return this.generateRgScript();
    } else {
      return this.generateGenericScript(query);
    }
  }

  private generateRDFScript(): string {
    return `# Generated RDF Analysis Script
import MDAnalysis as mda
import numpy as np
import matplotlib.pyplot as plt
from MDAnalysis.analysis.rdf import InterRDF

# Load trajectory
u = mda.Universe('topology.gro', 'trajectory.xtc')

# Define atom groups
water_O = u.select_atoms('name OW')  # Water oxygens
sodium = u.select_atoms('name NA')   # Sodium ions

# Calculate RDF
rdf = InterRDF(water_O, sodium, nbins=75, range=(0.0, 15.0))
rdf.run()

# Create publication-ready plot
plt.figure(figsize=(8, 6))
plt.plot(rdf.results.bins, rdf.results.rdf, 'b-', linewidth=2, label='Na⁺-OW RDF')
plt.xlabel('Distance (Å)', fontsize=14)
plt.ylabel('g(r)', fontsize=14)
plt.title('Radial Distribution Function: Na⁺ - Water Oxygens', fontsize=16)
plt.grid(True, alpha=0.3)
plt.legend(fontsize=12)
plt.xlim(0, 15)
plt.tight_layout()
plt.savefig('na_water_rdf.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"First peak at {rdf.results.bins[np.argmax(rdf.results.rdf)]:.2f} Å")
print(f"Coordination number: {np.trapz(rdf.results.rdf[:np.argmin(rdf.results.rdf[5:15])+5]):.1f}")`;
  }

  private generateRMSDScript(): string {
    return `# Generated RMSD Analysis Script
import MDAnalysis as mda
import matplotlib.pyplot as plt
from MDAnalysis.analysis import rms

# Load trajectory
u = mda.Universe('topology.gro', 'trajectory.xtc')

# Define selection (protein backbone)
protein = u.select_atoms('protein and name CA')

# Calculate RMSD
rmsd = rms.RMSD(protein, protein, select='protein and name CA', ref_frame=0)
rmsd.run()

# Create publication-ready plot
plt.figure(figsize=(10, 6))
time_ns = rmsd.results.time / 1000  # Convert ps to ns
plt.plot(time_ns, rmsd.results.rmsd, 'r-', linewidth=2)
plt.xlabel('Time (ns)', fontsize=14)
plt.ylabel('RMSD (Å)', fontsize=14)
plt.title('Root Mean Square Deviation - Protein Backbone', fontsize=16)
plt.grid(True, alpha=0.3)
plt.xlim(0, time_ns[-1])
plt.tight_layout()
plt.savefig('protein_rmsd.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"Average RMSD: {np.mean(rmsd.results.rmsd):.2f} ± {np.std(rmsd.results.rmsd):.2f} Å")
print(f"Final RMSD: {rmsd.results.rmsd[-1]:.2f} Å")`;
  }

  private generateDiffusionScript(): string {
    return `# Generated Diffusion Coefficient Analysis Script
import MDAnalysis as mda
import numpy as np
import matplotlib.pyplot as plt
from MDAnalysis.analysis.msd import EinsteinMSD

# Load trajectory
u = mda.Universe('topology.gro', 'trajectory.xtc')

# Define solute molecules
solute = u.select_atoms('resname SOL')

# Calculate MSD
msd = EinsteinMSD(solute, select='all', msd_type='xyz', fft=True)
msd.run()

# Fit linear region for diffusion coefficient
# D = MSD / (6 * t) for 3D diffusion
time_ns = msd.results.timeseries / 1000  # Convert to ns
msd_values = msd.results.msds_by_particle.mean(axis=1)

# Fit linear region (typically 20-80% of trajectory)
start_idx = int(0.2 * len(time_ns))
end_idx = int(0.8 * len(time_ns))
slope, intercept = np.polyfit(time_ns[start_idx:end_idx], msd_values[start_idx:end_idx], 1)
D = slope / 6  # Diffusion coefficient (Å²/ns)

# Create publication-ready plot
plt.figure(figsize=(10, 6))
plt.plot(time_ns, msd_values, 'b-', linewidth=2, label='MSD')
plt.plot(time_ns[start_idx:end_idx], 
         slope * time_ns[start_idx:end_idx] + intercept, 
         'r--', linewidth=2, label=f'Linear fit (D = {D:.3f} Å²/ns)')
plt.xlabel('Time (ns)', fontsize=14)
plt.ylabel('MSD (Å²)', fontsize=14)
plt.title('Mean Square Displacement - Solute Diffusion', fontsize=16)
plt.legend(fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('solute_msd.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"Diffusion coefficient: {D:.4f} Å²/ns = {D*1e-5:.2e} cm²/s")`;
  }

  private generateHBondScript(): string {
    return `# Generated Hydrogen Bond Analysis Script
import MDAnalysis as mda
import matplotlib.pyplot as plt
from MDAnalysis.analysis.hydrogenbonds import HydrogenBondAnalysis

# Load trajectory
u = mda.Universe('topology.gro', 'trajectory.xtc')

# Define donor and acceptor groups
protein = u.select_atoms('protein')
ligand = u.select_atoms('resname LIG')

# Calculate hydrogen bonds
hbonds = HydrogenBondAnalysis(
    universe=u,
    donors_sel=protein,
    acceptors_sel=ligand,
    d_a_cutoff=3.5,
    d_h_a_angle_cutoff=150
)
hbonds.run()

# Analyze results
hb_counts = hbonds.count_by_time()
time_ns = u.trajectory.time / 1000

# Create publication-ready plot
plt.figure(figsize=(10, 6))
plt.plot(time_ns, hb_counts, 'g-', linewidth=2)
plt.axhline(y=np.mean(hb_counts), color='r', linestyle='--', 
           label=f'Average: {np.mean(hb_counts):.1f} H-bonds')
plt.xlabel('Time (ns)', fontsize=14)
plt.ylabel('Number of Hydrogen Bonds', fontsize=14)
plt.title('Hydrogen Bonds: Protein - Ligand', fontsize=16)
plt.legend(fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('hbonds.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"Average H-bonds: {np.mean(hb_counts):.1f} ± {np.std(hb_counts):.1f}")
print(f"H-bond occupancy: {len(hb_counts[hb_counts > 0]) / len(hb_counts) * 100:.1f}%")`;
  }

  private generateRgScript(): string {
    return `# Generated Radius of Gyration Analysis Script
import MDAnalysis as mda
import numpy as np
import matplotlib.pyplot as plt
from MDAnalysis.analysis.polymer import RadiusOfGyration

# Load trajectory
u = mda.Universe('topology.gro', 'trajectory.xtc')

# Define polymer chains
polymer = u.select_atoms('resname POL')

# Calculate radius of gyration
rg = RadiusOfGyration(polymer).run()

# Create publication-ready plot
time_ns = u.trajectory.time / 1000
plt.figure(figsize=(10, 6))
plt.plot(time_ns, rg.results.radius_of_gyration, 'purple', linewidth=2)
plt.axhline(y=np.mean(rg.results.radius_of_gyration), color='orange', 
           linestyle='--', label=f'Average: {np.mean(rg.results.radius_of_gyration):.2f} Å')
plt.xlabel('Time (ns)', fontsize=14)
plt.ylabel('Radius of Gyration (Å)', fontsize=14)
plt.title('Polymer Chain Compactness', fontsize=16)
plt.legend(fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('rg_polymer.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"Average Rg: {np.mean(rg.results.radius_of_gyration):.2f} ± {np.std(rg.results.radius_of_gyration):.2f} Å")`;
  }

  private generateGenericScript(query: string): string {
    return `# Generated Analysis Script
import MDAnalysis as mda
import numpy as np
import matplotlib.pyplot as plt

# Load trajectory
u = mda.Universe('topology.gro', 'trajectory.xtc')

# Analysis based on query: "${query}"
print(f"Loaded trajectory with {len(u.trajectory)} frames")
print(f"System contains {u.atoms.n_atoms} atoms")

# Define atom selections
# TODO: Customize based on specific analysis requirements

# Perform analysis
# TODO: Implement specific analysis workflow

# Create visualization
plt.figure(figsize=(10, 6))
# TODO: Add appropriate plotting code
plt.xlabel('Time or Distance')
plt.ylabel('Property')
plt.title('MD Analysis Results')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('analysis_result.png', dpi=300, bbox_inches='tight')
plt.show()

print("Analysis complete. Please customize the script for your specific requirements.")`;
  }

  async executeScript(script: string): Promise<{plots: PlotData[], structures: StructureData[]}> {
    if (!this.currentSessionId) {
      throw new Error('No active session. Please upload files first.');
    }

    try {
      const response = await fetch(`${this.backendUrl}/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          script: script,
          session_id: this.currentSessionId,
          query: 'Analysis request'
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Analysis failed');
      }

      const result: BackendResponse = await response.json();
      
      if (!result.success) {
        throw new Error(`Script execution failed: ${result.stderr}`);
      }

      // Convert backend plots to frontend format
      const plots: PlotData[] = result.plots.map((plot, index) => ({
        id: `plot_${Date.now()}_${index}`,
        type: this.inferPlotType(plot.filename, result.stdout),
        title: this.generatePlotTitle(plot.filename, result.stdout),
        data: {
          x: [], // Real data would be extracted from the analysis
          y: [],
          labels: []
        },
        config: {
          xLabel: 'X Axis',
          yLabel: 'Y Axis',
          color: '#2563eb',
          style: 'line'
        },
        imageData: `data:image/${plot.type};base64,${plot.data}` // Add base64 image data
      }));

      // For now, no structures are returned, but this could be extended
      const structures: StructureData[] = [];

      return { plots, structures };
    } catch (error) {
      console.error('Script execution error:', error);
      throw new Error(`Failed to execute script: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private inferPlotType(filename: string, stdout: string): PlotData['type'] {
    const lower = filename.toLowerCase() + ' ' + stdout.toLowerCase();
    if (lower.includes('rdf')) return 'rdf';
    if (lower.includes('rmsd')) return 'rmsd';
    if (lower.includes('rmsf')) return 'rmsf';
    if (lower.includes('msd')) return 'msd';
    if (lower.includes('hbond')) return 'hbond';
    if (lower.includes('contact')) return 'contact';
    return 'rdf'; // default
  }

  private generatePlotTitle(filename: string, stdout: string): string {
    const type = this.inferPlotType(filename, stdout);
    const typeNames = {
      rdf: 'Radial Distribution Function',
      rmsd: 'Root Mean Square Deviation',
      rmsf: 'Root Mean Square Fluctuation',
      msd: 'Mean Square Displacement',
      hbond: 'Hydrogen Bond Analysis',
      contact: 'Contact Analysis',
      fes: 'Free Energy Surface'
    };
    return typeNames[type] || 'Analysis Result';
  }
}