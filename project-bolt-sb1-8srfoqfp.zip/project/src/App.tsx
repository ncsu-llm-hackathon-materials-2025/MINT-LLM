import React, { useState } from 'react';
import { Atom, Home } from 'lucide-react';
import EngineSelection from './components/EngineSelection';
import ApiKeyInput from './components/ApiKeyInput';
import FileUpload from './components/FileUpload';
import ChatbotInterface from './components/ChatbotInterface';
import AnalysisResults from './components/AnalysisResults';
import PopupChatbot from './components/PopupChatbot';
import { MDEngine, UploadedFile, AnalysisPlan } from './types';
import { parseFiles } from './utils/parsers';

export interface AppState {
  currentStep: 'engine' | 'apikey' | 'upload' | 'chat' | 'results';
  selectedEngine: MDEngine | null;
  apiKey: string;
  uploadedFiles: UploadedFile[];
  analysisPlan: AnalysisPlan | null;
  analysisResults: any | null;
}

function App() {
  const [appState, setAppState] = useState<AppState>({
    currentStep: 'engine',
    selectedEngine: null,
    apiKey: '',
    uploadedFiles: [],
    analysisPlan: null,
    analysisResults: null,
  });

  const resetApp = () => {
    setAppState({
      currentStep: 'engine',
      selectedEngine: null,
      apiKey: '',
      uploadedFiles: [],
      analysisPlan: null,
      analysisResults: null,
    });
  };

  const updateAppState = (updates: Partial<AppState>) => {
    setAppState(prev => ({ ...prev, ...updates }));
  };

  // Parse data for chatbot when files are available
  const parsedData = appState.uploadedFiles.length > 0 && appState.selectedEngine 
    ? (() => {
        try {
          return parseFiles(appState.uploadedFiles, appState.selectedEngine);
        } catch (error) {
          console.error('Error parsing files for chatbot:', error);
          return null;
        }
      })()
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-indigo-600 rounded-lg">
                <Atom className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">MINT LLM</h1>
                <p className="text-sm text-gray-600">Molecular INsight Toolkit</p>
              </div>
            </div>
            <button
              onClick={resetApp}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              <Home className="w-4 h-4" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {appState.currentStep === 'engine' && (
          <EngineSelection
            selectedEngine={appState.selectedEngine}
            onEngineSelect={(engine) => updateAppState({ selectedEngine: engine, currentStep: 'apikey' })}
          />
        )}

        {appState.currentStep === 'apikey' && (
          <ApiKeyInput
            apiKey={appState.apiKey}
            onApiKeySubmit={(apiKey) => updateAppState({ apiKey, currentStep: 'upload' })}
            onBack={() => updateAppState({ currentStep: 'engine' })}
          />
        )}

        {appState.currentStep === 'upload' && (
          <FileUpload
            engine={appState.selectedEngine!}
            uploadedFiles={appState.uploadedFiles}
            onFilesUpdate={(files) => updateAppState({ uploadedFiles: files })}
            onContinue={() => updateAppState({ currentStep: 'chat' })}
            onBack={() => updateAppState({ currentStep: 'apikey' })}
          />
        )}

        {appState.currentStep === 'chat' && (
          <ChatbotInterface
            engine={appState.selectedEngine!}
            uploadedFiles={appState.uploadedFiles}
            apiKey={appState.apiKey}
            onAnalysisPlan={(plan) => updateAppState({ analysisPlan: plan, currentStep: 'results' })}
            onBack={() => updateAppState({ currentStep: 'upload' })}
          />
        )}

        {appState.currentStep === 'results' && (
          <AnalysisResults
            engine={appState.selectedEngine!}
            uploadedFiles={appState.uploadedFiles}
            analysisPlan={appState.analysisPlan!}
            apiKey={appState.apiKey}
            onBack={() => updateAppState({ currentStep: 'chat' })}
            onNewAnalysis={() => updateAppState({ currentStep: 'chat', analysisPlan: null })}
          />
        )}
      </main>

      {/* Popup Chatbot - Only show on non-results pages */}
      {appState.currentStep !== 'results' && (
        <PopupChatbot
          uploadedFiles={appState.uploadedFiles}
          parsedData={parsedData}
          engine={appState.selectedEngine}
          apiKey={appState.apiKey}
        />
      )}
    </div>
  );
}

export default App;