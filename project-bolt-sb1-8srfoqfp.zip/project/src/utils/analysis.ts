import { AnalysisResult, ParsedData } from '../types';

// Helper function to calculate buffered min/max values
function getBufferedMinMax(values: number[], bufferPercentage: number = 0.1): [number, number] {
  if (values.length === 0) return [0, 1];
  
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min;
  const buffer = range * bufferPercentage;
  
  // If range is very small or zero, use a default buffer
  const finalBuffer = range > 0 ? buffer : Math.abs(min) * 0.1 || 1;
  
  return [min - finalBuffer, max + finalBuffer];
}

export async function performAnalysis(
  type: string,
  property: string,
  data: ParsedData,
  parameters: { blockSize: number; smoothingWindow: number }
): Promise<AnalysisResult | null> {
  const propertyIndex = data.properties[property.toLowerCase()];
  if (propertyIndex === undefined || !data.data.length) {
    return null;
  }

  const values = data.data.map(row => row[propertyIndex]);
  const timeValues = data.data.map(row => row[data.timeColumn]);

  switch (type) {
    case 'timeseries':
      return createTimeSeriesAnalysis(property, timeValues, values, parameters);
    case 'histogram':
      return createHistogramAnalysis(property, values);
    case 'drift':
      return createDriftAnalysis(property, timeValues, values);
    case 'blocks':
      return createBlockAnalysis(property, values, parameters.blockSize);
    case 'autocorr':
      return createAutocorrelationAnalysis(property, values);
    default:
      return null;
  }
}

function createTimeSeriesAnalysis(
  property: string,
  timeValues: number[],
  values: number[],
  parameters: { smoothingWindow: number }
): AnalysisResult {
  const stats = calculateStatistics(values);
  const drift = calculateLinearDrift(timeValues, values);
  const plot = generateTimeSeriesPlot(timeValues, values, parameters.smoothingWindow, property);

  return {
    type: 'timeseries',
    property,
    data: { time: timeValues, values },
    plot,
    statistics: { ...stats, drift },
  };
}

function createHistogramAnalysis(property: string, values: number[]): AnalysisResult {
  const stats = calculateStatistics(values);
  const plot = generateHistogramPlot(values, property);

  return {
    type: 'histogram',
    property,
    data: { values },
    plot,
    statistics: stats,
  };
}

function createDriftAnalysis(property: string, timeValues: number[], values: number[]): AnalysisResult {
  const stats = calculateStatistics(values);
  const drift = calculateLinearDrift(timeValues, values);
  const plot = generateDriftPlot(timeValues, values, drift, property);

  return {
    type: 'drift',
    property,
    data: { time: timeValues, values },
    plot,
    statistics: { ...stats, drift },
  };
}

function createBlockAnalysis(property: string, values: number[], blockSize: number): AnalysisResult {
  const blocks: number[][] = [];
  for (let i = 0; i < values.length; i += blockSize) {
    blocks.push(values.slice(i, i + blockSize));
  }

  const blockStats = blocks.map(block => calculateStatistics(block));
  const plot = generateBlockAnalysisPlot(blockStats, property);

  const overallStats = calculateStatistics(values);

  return {
    type: 'blocks',
    property,
    data: { blocks: blockStats },
    plot,
    statistics: overallStats,
  };
}

function createAutocorrelationAnalysis(property: string, values: number[]): AnalysisResult {
  const autocorr = calculateAutocorrelation(values);
  const plot = generateAutocorrelationPlot(autocorr, property);
  const stats = calculateStatistics(values);

  return {
    type: 'autocorr',
    property,
    data: { autocorrelation: autocorr },
    plot,
    statistics: stats,
  };
}

function calculateStatistics(values: number[]) {
  const n = values.length;
  const mean = values.reduce((sum, val) => sum + val, 0) / n;
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (n - 1);
  const std = Math.sqrt(variance);
  const sem = std / Math.sqrt(n);
  const ci95: [number, number] = [mean - 1.96 * sem, mean + 1.96 * sem];

  return { mean, std, ci95 };
}

function calculateLinearDrift(timeValues: number[], values: number[]) {
  const n = timeValues.length;
  const meanTime = timeValues.reduce((sum, t) => sum + t, 0) / n;
  const meanValue = values.reduce((sum, v) => sum + v, 0) / n;

  let numerator = 0;
  let denominator = 0;

  for (let i = 0; i < n; i++) {
    const dt = timeValues[i] - meanTime;
    const dv = values[i] - meanValue;
    numerator += dt * dv;
    denominator += dt * dt;
  }

  const slope = numerator / denominator;
  
  // Calculate R²
  const yPred = timeValues.map(t => slope * (t - meanTime) + meanValue);
  const ssRes = values.reduce((sum, val, i) => sum + Math.pow(val - yPred[i], 2), 0);
  const ssTot = values.reduce((sum, val) => sum + Math.pow(val - meanValue, 2), 0);
  const rSquared = 1 - ssRes / ssTot;

  // Calculate confidence interval for slope
  const residuals = values.map((val, i) => val - yPred[i]);
  const mse = residuals.reduce((sum, r) => sum + r * r, 0) / (n - 2);
  const slopeStdError = Math.sqrt(mse / denominator);
  const tValue = 1.96; // 95% CI
  const slopeCI: [number, number] = [
    slope - tValue * slopeStdError,
    slope + tValue * slopeStdError
  ];

  return { slope, rSquared, slopeCI };
}

function calculateAutocorrelation(values: number[]): number[] {
  const n = values.length;
  const mean = values.reduce((sum, val) => sum + val, 0) / n;
  const autocorr: number[] = [];

  for (let lag = 0; lag < Math.min(n / 4, 100); lag++) {
    let numerator = 0;
    let denominator = 0;

    for (let i = 0; i < n - lag; i++) {
      numerator += (values[i] - mean) * (values[i + lag] - mean);
    }

    for (let i = 0; i < n; i++) {
      denominator += Math.pow(values[i] - mean, 2);
    }

    autocorr.push(numerator / denominator);
  }

  return autocorr;
}

// Plot generation functions (simplified versions that return base64 encoded SVG)
function generateTimeSeriesPlot(
  timeValues: number[],
  values: number[],
  smoothingWindow: number,
  property: string
): string {
  const width = 800;
  const height = 400;
  const margin = { top: 40, right: 40, bottom: 80, left: 100 };

  const [xMin, xMax] = getBufferedMinMax(timeValues, 0.05);
  const [yMin, yMax] = getBufferedMinMax(values, 0.1);

  const xScale = (x: number) => margin.left + ((x - xMin) / (xMax - xMin)) * (width - margin.left - margin.right);
  const yScale = (y: number) => height - margin.bottom - ((y - yMin) / (yMax - yMin)) * (height - margin.top - margin.bottom);

  // Generate tick values
  const xTicks = generateTicks(xMin, xMax, 5);
  const yTicks = generateTicks(yMin, yMax, 5);

  // Generate moving average
  const smoothed: number[] = [];
  for (let i = 0; i < values.length; i++) {
    const start = Math.max(0, i - Math.floor(smoothingWindow / 2));
    const end = Math.min(values.length, i + Math.floor(smoothingWindow / 2) + 1);
    const windowValues = values.slice(start, end);
    const avg = windowValues.reduce((sum, val) => sum + val, 0) / windowValues.length;
    smoothed.push(avg);
  }

  const pathData = timeValues.map((t, i) => `${i === 0 ? 'M' : 'L'} ${xScale(t)} ${yScale(values[i])}`).join(' ');
  const smoothedPath = timeValues.map((t, i) => `${i === 0 ? 'M' : 'L'} ${xScale(t)} ${yScale(smoothed[i])}`).join(' ');

  // Format property name for display
  const formattedProperty = formatPropertyName(property);
  const units = getPropertyUnits(property);
  const yAxisLabel = units ? `${formattedProperty} (${units})` : formattedProperty;

  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <style>
          .axis { stroke: #333; stroke-width: 1.5; }
          .grid { stroke: #e0e0e0; stroke-width: 0.5; }
          .data-line { fill: none; stroke: #3B82F6; stroke-width: 1; opacity: 0.7; }
          .smooth-line { fill: none; stroke: #DC2626; stroke-width: 2; }
          .title { font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; text-anchor: middle; fill: #333; }
          .axis-label { font-family: Arial, sans-serif; font-size: 14px; font-weight: 600; text-anchor: middle; fill: #333; }
          .tick-label { font-family: Arial, sans-serif; font-size: 11px; text-anchor: middle; fill: #666; }
          .legend-text { font-family: Arial, sans-serif; font-size: 12px; fill: #333; }
        </style>
      </defs>
      
      <!-- Grid lines -->
      ${xTicks.map(tick => {
        const x = xScale(tick);
        return `<line x1="${x}" y1="${margin.top}" x2="${x}" y2="${height - margin.bottom}" class="grid" />`;
      }).join('')}
      
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="grid" />`;
      }).join('')}
      
      <!-- Axes -->
      <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="axis" />
      <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="axis" />
      
      <!-- Tick marks and labels -->
      ${xTicks.map(tick => {
        const x = xScale(tick);
        return `
          <line x1="${x}" y1="${height - margin.bottom}" x2="${x}" y2="${height - margin.bottom + 6}" class="axis" />
          <text x="${x}" y="${height - margin.bottom + 20}" class="tick-label">${formatTickValue(tick)}</text>
        `;
      }).join('')}
      
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `
          <line x1="${margin.left}" y1="${y}" x2="${margin.left - 6}" y2="${y}" class="axis" />
          <text x="${margin.left - 12}" y="${y + 4}" class="tick-label" text-anchor="end">${formatTickValue(tick)}</text>
        `;
      }).join('')}
      
      <!-- Data -->
      <path d="${pathData}" class="data-line" />
      <path d="${smoothedPath}" class="smooth-line" />
      
      <!-- Labels -->
      <text x="${width / 2}" y="${height - 25}" class="axis-label">Timestep</text>
      <text x="25" y="${height / 2}" class="axis-label" transform="rotate(-90, 25, ${height / 2})">${yAxisLabel}</text>
      <text x="${width / 2}" y="25" class="title">Time Series Analysis: ${formattedProperty}</text>
      
      <!-- Legend -->
      <g transform="translate(${width - 150}, 60)">
        <line x1="0" y1="0" x2="20" y2="0" class="data-line" />
        <text x="25" y="4" class="legend-text">Raw Data</text>
        <line x1="0" y1="15" x2="20" y2="15" class="smooth-line" />
        <text x="25" y="19" class="legend-text">Smoothed (${smoothingWindow} pt avg)</text>
      </g>
    </svg>
  `;

  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

function generateHistogramPlot(values: number[], property: string): string {
  const width = 800;
  const height = 400;
  const margin = { top: 40, right: 40, bottom: 80, left: 100 };

  const [min, max] = getBufferedMinMax(values, 0.05);
  const dataMin = Math.min(...values);
  const dataMax = Math.max(...values);
  const dataRange = dataMax - dataMin;
  
  const binCount = Math.min(50, Math.ceil(Math.sqrt(values.length)));
  const binWidth = dataRange / binCount;

  const bins: number[] = new Array(binCount).fill(0);
  values.forEach(value => {
    const binIndex = Math.min(binCount - 1, Math.floor((value - dataMin) / binWidth));
    bins[binIndex]++;
  });

  const maxBinHeight = Math.max(...bins);
  const barWidth = (width - margin.left - margin.right) / binCount;

  const xScale = (x: number) => margin.left + ((x - min) / (max - min)) * (width - margin.left - margin.right);
  const yScale = (y: number) => height - margin.bottom - (y / maxBinHeight) * (height - margin.top - margin.bottom);

  // Generate tick values
  const xTicks = generateTicks(min, max, 5);
  const yTicks = generateTicks(0, maxBinHeight, 5);

  // Format property name for display
  const formattedProperty = formatPropertyName(property);
  const units = getPropertyUnits(property);
  const xAxisLabel = units ? `${formattedProperty} (${units})` : formattedProperty;

  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <style>
          .axis { stroke: #333; stroke-width: 1.5; }
          .grid { stroke: #e0e0e0; stroke-width: 0.5; }
          .bar { fill: #3B82F6; stroke: white; stroke-width: 1; }
          .title { font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; text-anchor: middle; fill: #333; }
          .axis-label { font-family: Arial, sans-serif; font-size: 14px; font-weight: 600; text-anchor: middle; fill: #333; }
          .tick-label { font-family: Arial, sans-serif; font-size: 11px; text-anchor: middle; fill: #666; }
        </style>
      </defs>
      
      <!-- Grid lines -->
      ${xTicks.map(tick => {
        const x = xScale(tick);
        return `<line x1="${x}" y1="${margin.top}" x2="${x}" y2="${height - margin.bottom}" class="grid" />`;
      }).join('')}
      
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="grid" />`;
      }).join('')}
      
      <!-- Axes -->
      <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="axis" />
      <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="axis" />
      
      <!-- Tick marks and labels -->
      ${xTicks.map(tick => {
        const x = xScale(tick);
        return `
          <line x1="${x}" y1="${height - margin.bottom}" x2="${x}" y2="${height - margin.bottom + 6}" class="axis" />
          <text x="${x}" y="${height - margin.bottom + 20}" class="tick-label">${formatTickValue(tick)}</text>
        `;
      }).join('')}
      
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `
          <line x1="${margin.left}" y1="${y}" x2="${margin.left - 6}" y2="${y}" class="axis" />
          <text x="${margin.left - 12}" y="${y + 4}" class="tick-label" text-anchor="end">${Math.round(tick)}</text>
        `;
      }).join('')}
      
      <!-- Bars -->
      ${bins.map((count, i) => {
        const binStart = dataMin + i * binWidth;
        const x = xScale(binStart);
        const y = yScale(count);
        const barHeight = height - margin.bottom - y;
        const scaledBarWidth = xScale(binStart + binWidth) - x;
        return `<rect x="${x}" y="${y}" width="${scaledBarWidth - 1}" height="${barHeight}" class="bar" />`;
      }).join('')}
      
      <!-- Labels -->
      <text x="${width / 2}" y="${height - 25}" class="axis-label">${xAxisLabel}</text>
      <text x="25" y="${height / 2}" class="axis-label" transform="rotate(-90, 25, ${height / 2})">Frequency</text>
      <text x="${width / 2}" y="25" class="title">Distribution: ${formattedProperty}</text>
    </svg>
  `;

  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

function generateDriftPlot(
  timeValues: number[],
  values: number[],
  drift: { slope: number; rSquared: number },
  property: string
): string {
  const width = 800;
  const height = 400;
  const margin = { top: 40, right: 40, bottom: 80, left: 100 };

  const [xMin, xMax] = getBufferedMinMax(timeValues, 0.05);
  const [yMin, yMax] = getBufferedMinMax(values, 0.1);

  const xScale = (x: number) => margin.left + ((x - xMin) / (xMax - xMin)) * (width - margin.left - margin.right);
  const yScale = (y: number) => height - margin.bottom - ((y - yMin) / (yMax - yMin)) * (height - margin.top - margin.bottom);

  const meanTime = timeValues.reduce((sum, t) => sum + t, 0) / timeValues.length;
  const meanValue = values.reduce((sum, v) => sum + v, 0) / values.length;
  
  // Use actual data range for trend line calculation, not buffered range
  const actualXMin = Math.min(...timeValues);
  const actualXMax = Math.max(...timeValues);
  const trendY1 = drift.slope * (actualXMin - meanTime) + meanValue;
  const trendY2 = drift.slope * (actualXMax - meanTime) + meanValue;

  const pathData = timeValues.map((t, i) => `${i === 0 ? 'M' : 'L'} ${xScale(t)} ${yScale(values[i])}`).join(' ');

  // Generate tick values
  const xTicks = generateTicks(xMin, xMax, 5);
  const yTicks = generateTicks(yMin, yMax, 5);

  // Format property name for display
  const formattedProperty = formatPropertyName(property);
  const units = getPropertyUnits(property);
  const yAxisLabel = units ? `${formattedProperty} (${units})` : formattedProperty;

  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <style>
          .axis { stroke: #333; stroke-width: 1.5; }
          .grid { stroke: #e0e0e0; stroke-width: 0.5; }
          .data-line { fill: none; stroke: #3B82F6; stroke-width: 1; opacity: 0.7; }
          .trend-line { fill: none; stroke: #DC2626; stroke-width: 2; stroke-dasharray: 5,5; }
          .title { font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; text-anchor: middle; fill: #333; }
          .axis-label { font-family: Arial, sans-serif; font-size: 14px; font-weight: 600; text-anchor: middle; fill: #333; }
          .tick-label { font-family: Arial, sans-serif; font-size: 11px; text-anchor: middle; fill: #666; }
          .stats-text { font-family: Arial, sans-serif; font-size: 12px; fill: #333; }
        </style>
      </defs>
      
      <!-- Grid lines -->
      ${xTicks.map(tick => {
        const x = xScale(tick);
        return `<line x1="${x}" y1="${margin.top}" x2="${x}" y2="${height - margin.bottom}" class="grid" />`;
      }).join('')}
      
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="grid" />`;
      }).join('')}
      
      <!-- Axes -->
      <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="axis" />
      <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="axis" />
      
      <!-- Tick marks and labels -->
      ${xTicks.map(tick => {
        const x = xScale(tick);
        return `
          <line x1="${x}" y1="${height - margin.bottom}" x2="${x}" y2="${height - margin.bottom + 6}" class="axis" />
          <text x="${x}" y="${height - margin.bottom + 20}" class="tick-label">${formatTickValue(tick)}</text>
        `;
      }).join('')}
      
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `
          <line x1="${margin.left}" y1="${y}" x2="${margin.left - 6}" y2="${y}" class="axis" />
          <text x="${margin.left - 12}" y="${y + 4}" class="tick-label" text-anchor="end">${formatTickValue(tick)}</text>
        `;
      }).join('')}
      
      <!-- Data -->
      <path d="${pathData}" class="data-line" />
      <line x1="${xScale(actualXMin)}" y1="${yScale(trendY1)}" x2="${xScale(actualXMax)}" y2="${yScale(trendY2)}" class="trend-line" />
      
      <!-- Labels -->
      <text x="${width / 2}" y="${height - 25}" class="axis-label">Timestep</text>
      <text x="25" y="${height / 2}" class="axis-label" transform="rotate(-90, 25, ${height / 2})">${yAxisLabel}</text>
      <text x="${width / 2}" y="25" class="title">Drift Analysis: ${formattedProperty}</text>
      
      <!-- Statistics -->
      <g transform="translate(${width - 220}, 60)">
        <rect x="-10" y="-15" width="210" height="50" fill="white" stroke="#ccc" stroke-width="1" rx="3"/>
        <text x="0" y="0" class="stats-text">Slope: ${drift.slope.toExponential(3)}</text>
        <text x="0" y="18" class="stats-text">R²: ${drift.rSquared.toFixed(4)}</text>
      </g>
    </svg>
  `;

  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

function generateBlockAnalysisPlot(
  blockStats: Array<{ mean: number; std: number; ci95: [number, number] }>,
  property: string
): string {
  const width = 800;
  const height = 400;
  const margin = { top: 40, right: 40, bottom: 80, left: 100 };

  const means = blockStats.map(stats => stats.mean);
  const allValues = blockStats.flatMap(stats => [stats.ci95[0], stats.ci95[1]]);
  const [yMin, yMax] = getBufferedMinMax(allValues, 0.1);

  const barWidth = (width - margin.left - margin.right) / blockStats.length;
  const xScale = (x: number) => margin.left + (x / (blockStats.length - 1)) * (width - margin.left - margin.right);
  const yScale = (y: number) => height - margin.bottom - ((y - yMin) / (yMax - yMin)) * (height - margin.top - margin.bottom);

  // Generate tick values
  const xTicks = Array.from({length: Math.min(6, blockStats.length)}, (_, i) => 
    Math.round(i * (blockStats.length - 1) / Math.max(1, Math.min(5, blockStats.length - 1)))
  );
  const yTicks = generateTicks(yMin, yMax, 5);

  // Format property name for display
  const formattedProperty = formatPropertyName(property);
  const units = getPropertyUnits(property);
  const yAxisLabel = units ? `${formattedProperty} (${units})` : formattedProperty;

  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <style>
          .axis { stroke: #333; stroke-width: 1.5; }
          .grid { stroke: #e0e0e0; stroke-width: 0.5; }
          .bar { fill: #3B82F6; opacity: 0.7; }
          .error-bar { stroke: #333; stroke-width: 2; }
          .title { font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; text-anchor: middle; fill: #333; }
          .axis-label { font-family: Arial, sans-serif; font-size: 14px; font-weight: 600; text-anchor: middle; fill: #333; }
          .tick-label { font-family: Arial, sans-serif; font-size: 11px; text-anchor: middle; fill: #666; }
        </style>
      </defs>
      
      <!-- Grid lines -->
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="grid" />`;
      }).join('')}
      
      <!-- Axes -->
      <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="axis" />
      <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="axis" />
      
      <!-- Y-axis tick marks and labels -->
      ${yTicks.map(tick => {
        const y = yScale(tick);
        return `
          <line x1="${margin.left}" y1="${y}" x2="${margin.left - 6}" y2="${y}" class="axis" />
          <text x="${margin.left - 12}" y="${y + 4}" class="tick-label" text-anchor="end">${formatTickValue(tick)}</text>
        `;
      }).join('')}
      
      <!-- X-axis tick marks and labels -->
      ${xTicks.map(tick => {
        const x = margin.left + tick * barWidth + barWidth/2;
        return `
          <line x1="${x}" y1="${height - margin.bottom}" x2="${x}" y2="${height - margin.bottom + 6}" class="axis" />
          <text x="${x}" y="${height - margin.bottom + 20}" class="tick-label">${tick + 1}</text>
        `;
      }).join('')}
      
      <!-- Bars and error bars -->
      ${blockStats.map((stats, i) => {
        const x = margin.left + i * barWidth;
        
        const zeroY = yScale(0);
        const meanY = yScale(stats.mean);
        const barHeight = Math.abs(meanY - zeroY);
        const barY = Math.min(meanY, zeroY);
        
        const errorTop = yScale(stats.ci95[1]);
        const errorBottom = yScale(stats.ci95[0]);
        
        return `
          <rect x="${x + 2}" y="${barY}" width="${barWidth - 4}" height="${barHeight}" class="bar" />
          <line x1="${x + barWidth/2}" y1="${errorBottom}" x2="${x + barWidth/2}" y2="${errorTop}" class="error-bar" />
          <line x1="${x + barWidth/2 - 4}" y1="${errorTop}" x2="${x + barWidth/2 + 4}" y2="${errorTop}" class="error-bar" />
          <line x1="${x + barWidth/2 - 4}" y1="${errorBottom}" x2="${x + barWidth/2 + 4}" y2="${errorBottom}" class="error-bar" />
        `;
      }).join('')}
      
      <!-- Labels -->
      <text x="${width / 2}" y="${height - 25}" class="axis-label">Block Number</text>
      <text x="25" y="${height / 2}" class="axis-label" transform="rotate(-90, 25, ${height / 2})">${yAxisLabel}</text>
      <text x="${width / 2}" y="25" class="title">Block Analysis: ${formattedProperty}</text>
    </svg>
  `;

  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

function generateAutocorrelationPlot(autocorr: number[], property: string): string {
  const width = 800;
  const height = 400;
  const margin = { top: 20, right: 30, bottom: 40, left: 60 };

  const maxLag = autocorr.length - 1;
  const [minCorr, maxCorr] = getBufferedMinMax(autocorr, 0.1);
  
  const xScale = (x: number) => margin.left + (x / maxLag) * (width - margin.left - margin.right);
  const yScale = (y: number) => height - margin.bottom - ((y - minCorr) / (maxCorr - minCorr)) * (height - margin.top - margin.bottom);

  const pathData = autocorr.map((corr, lag) => `${lag === 0 ? 'M' : 'L'} ${xScale(lag)} ${yScale(corr)}`).join(' ');

  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <style>
          .axis { stroke: #666; stroke-width: 1; }
          .data-line { fill: none; stroke: #3B82F6; stroke-width: 2; }
          .zero-line { stroke: #999; stroke-width: 1; stroke-dasharray: 3,3; }
          .title { font-family: Arial; font-size: 16px; font-weight: bold; text-anchor: middle; }
          .label { font-family: Arial; font-size: 12px; text-anchor: middle; }
        </style>
      </defs>
      
      <!-- Zero line -->
      <line x1="${margin.left}" y1="${yScale(0)}" x2="${width - margin.right}" y2="${yScale(0)}" class="zero-line" />
      
      <!-- Axes -->
      <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" class="axis" />
      <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${height - margin.bottom}" class="axis" />
      
      <!-- Data -->
      <path d="${pathData}" class="data-line" />
      
      <!-- Labels -->
      <text x="${width / 2}" y="${height - 10}" class="label">Lag</text>
      <text x="20" y="${height / 2}" class="label" transform="rotate(-90, 20, ${height / 2})">Autocorrelation</text>
      <text x="${width / 2}" y="15" class="title">Autocorrelation: ${property.replace(/_/g, ' ').toUpperCase()}</text>
    </svg>
  `;

  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

// Helper functions for plot formatting
function generateTicks(min: number, max: number, targetCount: number): number[] {
  if (min === max) return [min];
  
  const range = max - min;
  const roughStep = range / (targetCount - 1);
  
  // Find a nice step size
  const magnitude = Math.pow(10, Math.floor(Math.log10(roughStep)));
  const normalizedStep = roughStep / magnitude;
  
  let niceStep;
  if (normalizedStep <= 1) niceStep = 1;
  else if (normalizedStep <= 2) niceStep = 2;
  else if (normalizedStep <= 5) niceStep = 5;
  else niceStep = 10;
  
  const step = niceStep * magnitude;
  
  // Generate ticks
  const ticks: number[] = [];
  const start = Math.ceil(min / step) * step;
  
  for (let tick = start; tick <= max + step * 0.001; tick += step) {
    if (tick >= min - step * 0.001) {
      ticks.push(tick);
    }
  }
  
  return ticks.length > 0 ? ticks : [min, max];
}

function formatTickValue(value: number): string {
  if (Math.abs(value) >= 1000000) {
    return value.toExponential(1);
  } else if (Math.abs(value) >= 1000) {
    return (value / 1000).toFixed(1) + 'k';
  } else if (Math.abs(value) >= 1) {
    return value.toFixed(1);
  } else if (Math.abs(value) >= 0.01) {
    return value.toFixed(3);
  } else {
    return value.toExponential(2);
  }
}

function formatPropertyName(property: string): string {
  return property
    .replace(/_/g, ' ')
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

function getPropertyUnits(property: string): string | null {
  const units: Record<string, string> = {
    'temperature': 'K',
    'pressure': 'atm',
    'pressure_xx': 'atm',
    'pressure_yy': 'atm', 
    'pressure_zz': 'atm',
    'potential_energy': 'kcal/mol',
    'kinetic_energy': 'kcal/mol',
    'translational_kinetic_energy': 'kcal/mol',
    'rotational_kinetic_energy': 'kcal/mol',
    'total_energy': 'kcal/mol',
    'volume': 'Å³',
    'box_length_x': 'Å',
    'box_length_y': 'Å',
    'box_length_z': 'Å',
    'lx': 'Å',
    'ly': 'Å',
    'lz': 'Å',
    'density': 'g/cm³',
    'timestep': 'steps',
    'time': 'ps'
  };
  
  return units[property.toLowerCase()] || null;
}