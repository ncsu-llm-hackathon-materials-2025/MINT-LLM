import { MDEngine, UploadedFile, ParsedData } from '../types';

export function parseFiles(files: UploadedFile[], engine: MDEngine): ParsedData {
  switch (engine) {
    case 'lammps':
      return parseLAMMPSFiles(files);
    case 'gromacs':
      return parseGROMACSFiles(files);
    case 'amber':
      return parseAmberFiles(files);
    default:
      throw new Error(`Unsupported engine: ${engine}`);
  }
}

function parseLAMMPSFiles(files: UploadedFile[]): ParsedData {
  const allData: number[][] = [];
  let headers: string[] = [];
  const properties: Record<string, number> = {};
  let timeColumn = -1;

  for (const file of files) {
    const lines = file.content.split('\n').map(line => line.trim());
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      // Skip empty lines and comments
      if (!line || line.startsWith('#') || line.startsWith('LAMMPS')) {
        continue;
      }
      
      // Look for thermo output headers - more robust detection
      if (line.match(/^\s*Step\s+/) || (line.includes('Step') && line.includes('Temp'))) {
        const headerLine = line.split(/\s+/).filter(word => word.length > 0);
        
        // Validate this is actually a header line (contains expected MD properties)
        const expectedProps = ['Step', 'Temp', 'Press', 'PotEng', 'KinEng', 'TotEng', 'Volume', 'Density'];
        const hasValidProps = expectedProps.some(prop => 
          headerLine.some(header => header.toLowerCase().includes(prop.toLowerCase()))
        );
        
        if (!hasValidProps) continue;
        
        if (headers.length === 0) {
          headers = headerLine;
          
          // Map headers to standardized property names
          headerLine.forEach((header, index) => {
            const normalizedHeader = normalizePropertyName(header);
            if (normalizedHeader) {
              properties[normalizedHeader] = index;
            }
            
            // Identify time column
            if (header.toLowerCase() === 'step' || header.toLowerCase() === 'time') {
              timeColumn = index;
            }
          });
        }
        
        // Process data lines following the header
        i++;
        while (i < lines.length) {
          const dataLine = lines[i].trim();
          
          // Stop at end markers or new sections
          if (!dataLine || 
              dataLine.startsWith('Loop') || 
              dataLine.startsWith('WARNING') ||
              dataLine.startsWith('ERROR') ||
              dataLine.startsWith('Total wall time') ||
              dataLine.includes('Performance:') ||
              dataLine.match(/^\s*Step\s+/)) {
            break;
          }
          
          // Parse numeric data
          const values = dataLine.split(/\s+/).map(Number);
          
          // Validate data line: correct length and all numeric values
          if (values.length >= headers.length - 1 && // Allow slight length variation
              values.slice(0, headers.length).every(v => !isNaN(v) && isFinite(v))) {
            
            // Pad with zeros if slightly short
            while (values.length < headers.length) {
              values.push(0);
            }
            
            // Take only the expected number of columns
            const trimmedValues = values.slice(0, headers.length);
            allData.push(values);
          }
          i++;
        }
      }
    }
  }

  // Remove duplicate data points (same timestep)
  if (timeColumn >= 0 && allData.length > 1) {
    const uniqueData = [];
    const seenTimes = new Set();
    
    for (const row of allData) {
      const timeValue = row[timeColumn];
      if (!seenTimes.has(timeValue)) {
        seenTimes.add(timeValue);
        uniqueData.push(row);
      }
    }
    
    allData.length = 0;
    allData.push(...uniqueData);
  }

  // Sort by time if time column exists
  if (timeColumn >= 0) {
    allData.sort((a, b) => a[timeColumn] - b[timeColumn]);
  }

  return {
    headers,
    data: allData,
    timeColumn: Math.max(0, timeColumn),
    properties,
  };
}

// Helper function to normalize LAMMPS property names to standard format
function normalizePropertyName(header: string): string | null {
  const normalized = header.toLowerCase();
  
  // Map LAMMPS headers to standard property names
  const propertyMap: Record<string, string> = {
    'step': 'step',
    'time': 'time',
    'temp': 'temperature',
    'press': 'pressure', 
    'pxx': 'pressure_xx',
    'pyy': 'pressure_yy',
    'pzz': 'pressure_zz',
    'pxy': 'pressure_xy',
    'pxz': 'pressure_xz',
    'pyz': 'pressure_yz',
    'poteng': 'potential_energy',
    'kineng': 'kinetic_energy',
    'toteng': 'total_energy',
    'enthalpy': 'enthalpy',
    'volume': 'volume',
    'density': 'density',
    'lx': 'box_length_x',
    'ly': 'box_length_y', 
    'lz': 'box_length_z',
    'xy': 'box_tilt_xy',
    'xz': 'box_tilt_xz',
    'yz': 'box_tilt_yz'
  };
  
  return propertyMap[normalized] || null;
}

function parseGROMACSFiles(files: UploadedFile[]): ParsedData {
  const allData: number[][] = [];
  let headers: string[] = [];
  const properties: Record<string, number> = {};
  let timeColumn = -1;

  for (const file of files) {
    const lines = file.content.split('\n').map(line => line.trim()).filter(Boolean);
    
    if (file.type === 'xvg') {
      // Parse XVG files (gmx energy output)
      const dataLines = lines.filter(line => !line.startsWith('@') && !line.startsWith('#'));
      
      for (const line of dataLines) {
        const values = line.split(/\s+/).map(Number);
        if (values.length >= 2 && values.every(v => !isNaN(v))) {
          if (headers.length === 0) {
            headers = ['Time', 'Value'];
            properties['time'] = 0;
            properties['value'] = 1;
            timeColumn = 0;
          }
          allData.push(values);
        }
      }
    } else {
      // Parse md.log files
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // Look for energy output sections
        if (line.includes('Statistics over') || line.match(/\s+Time\s+/)) {
          // Try to find the header line
          while (i < lines.length && !lines[i].match(/^\s*Time\s+/)) {
            i++;
          }
          
          if (i < lines.length) {
            const headerLine = lines[i].split(/\s+/).filter(Boolean);
            if (headers.length === 0) {
              headers = headerLine;
              headerLine.forEach((header, index) => {
                const normalizedHeader = header.toLowerCase();
                properties[normalizedHeader] = index;
                if (normalizedHeader === 'time') {
                  timeColumn = index;
                }
              });
            }
            
            // Parse data lines
            i++;
            while (i < lines.length) {
              const dataLine = lines[i].trim();
              if (!dataLine || !dataLine.match(/^\s*[\d\.\-e\+]+/)) {
                break;
              }
              
              const values = dataLine.split(/\s+/).map(Number);
              if (values.length === headers.length && values.every(v => !isNaN(v))) {
                allData.push(values);
              }
              i++;
            }
          }
        }
      }
    }
  }

  // Sort by time if time column exists
  if (timeColumn >= 0) {
    allData.sort((a, b) => a[timeColumn] - b[timeColumn]);
  }

  return {
    headers,
    data: allData,
    timeColumn: Math.max(0, timeColumn),
    properties,
  };
}

function parseAmberFiles(files: UploadedFile[]): ParsedData {
  const allData: number[][] = [];
  let headers: string[] = [];
  const properties: Record<string, number> = {};
  let timeColumn = -1;

  for (const file of files) {
    const lines = file.content.split('\n').map(line => line.trim()).filter(Boolean);
    
    // First, try to parse the new structured format with explicit headers
    let foundStructuredFormat = false;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      // Look for the structured header format
      if (line.includes('timestep') && line.includes('potential_energy') && line.includes('kinetic_energy')) {
        console.log('Found structured Amber format header:', line);
        
        // Parse header - handle both comma and space separated
        const headerLine = line.includes(',') 
          ? line.split(',').map(h => h.trim())
          : line.split(/\s+/).filter(Boolean);
        
        if (headers.length === 0) {
          headers = headerLine;
          
          // Map headers to properties with normalized names
          headerLine.forEach((header, index) => {
            const normalizedHeader = normalizeAmberPropertyName(header);
            if (normalizedHeader) {
              properties[normalizedHeader] = index;
            }
            
            // Set time column
            if (header.toLowerCase() === 'timestep' || header.toLowerCase() === 'time') {
              timeColumn = index;
            }
          });
          
          console.log('Amber properties mapped:', properties);
          console.log('Time column set to:', timeColumn);
        }
        
        // Parse data lines following the header
        i++;
        while (i < lines.length) {
          const dataLine = lines[i].trim();
          
          if (!dataLine || dataLine.startsWith('#') || dataLine.includes('timestep')) {
            break;
          }
          
          // Parse numeric data - handle both comma and space separated
          const values = dataLine.includes(',')
            ? dataLine.split(',').map(v => parseFloat(v.trim()))
            : dataLine.split(/\s+/).map(v => parseFloat(v));
          
          // Validate data line
          if (values.length >= headers.length - 1 && 
              values.slice(0, headers.length).every(v => !isNaN(v) && isFinite(v))) {
            
            // Ensure we have the right number of columns
            while (values.length < headers.length) {
              values.push(0);
            }
            
            allData.push(values.slice(0, headers.length));
          }
          i++;
        }
        
        foundStructuredFormat = true;
        break;
      }
    }
    
    // If structured format not found, fall back to traditional Amber parsing
    if (!foundStructuredFormat) {
      console.log('Using traditional Amber parsing for file:', file.name);
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // Look for energy output sections
        if (line.includes('NSTEP') && line.includes('TIME(PS)')) {
          const parts = line.split(/\s+/);
          const nstepIndex = parts.indexOf('NSTEP');
          const timeIndex = parts.indexOf('TIME(PS)');
          
          if (nstepIndex >= 0 && timeIndex >= 0) {
            const nstepValue = parts[nstepIndex + 2];
            const timeValue = parts[timeIndex + 2];
            
            // Look for temperature line
            i++;
            let temperature = NaN, pressure = NaN, etot = NaN, ektot = NaN, epot = NaN;
            
            while (i < lines.length) {
              const currentLine = lines[i];
              
              if (currentLine.includes('TEMP(K)')) {
                const tempMatch = currentLine.match(/TEMP\(K\)\s*=\s*([\d\.\-e\+]+)/);
                if (tempMatch) temperature = parseFloat(tempMatch[1]);
              }
              
              if (currentLine.includes('PRESS')) {
                const pressMatch = currentLine.match(/PRESS\s*=\s*([\d\.\-e\+]+)/);
                if (pressMatch) pressure = parseFloat(pressMatch[1]);
              }
              
              if (currentLine.includes('Etot')) {
                const etotMatch = currentLine.match(/Etot\s*=\s*([\d\.\-e\+]+)/);
                if (etotMatch) etot = parseFloat(etotMatch[1]);
              }
              
              if (currentLine.includes('EKtot')) {
                const ektotMatch = currentLine.match(/EKtot\s*=\s*([\d\.\-e\+]+)/);
                if (ektotMatch) ektot = parseFloat(ektotMatch[1]);
              }
              
              if (currentLine.includes('EPtot')) {
                const epotMatch = currentLine.match(/EPtot\s*=\s*([\d\.\-e\+]+)/);
                if (epotMatch) epot = parseFloat(epotMatch[1]);
              }
              
              if (currentLine.includes('VOLUME') || 
                  currentLine.includes('DENSITY') ||
                  currentLine.includes('------')) {
                break;
              }
              
              i++;
            }
            
            // Initialize headers on first data point
            if (headers.length === 0) {
              headers = ['Step', 'Time', 'Temp', 'Press', 'Etot', 'EKtot', 'EPtot'];
              properties['step'] = 0;
              properties['time'] = 1;
              properties['temperature'] = 2;
              properties['pressure'] = 3;
              properties['total_energy'] = 4;
              properties['kinetic_energy'] = 5;
              properties['potential_energy'] = 6;
              timeColumn = 1;
            }
            
            // Add data point
            const dataPoint = [
              parseFloat(nstepValue) || 0,
              parseFloat(timeValue) || 0,
              temperature || 0,
              pressure || 0,
              etot || 0,
              ektot || 0,
              epot || 0,
            ];
            
            if (dataPoint.some(v => !isNaN(v))) {
              allData.push(dataPoint);
            }
          }
        }
      }
    }
  }

  console.log('Final Amber parsing results:');
  console.log('Headers:', headers);
  console.log('Properties:', properties);
  console.log('Data points:', allData.length);
  console.log('Time column:', timeColumn);

  // Sort by time if time column exists
  if (timeColumn >= 0) {
    allData.sort((a, b) => a[timeColumn] - b[timeColumn]);
  }

// Helper function to normalize Amber property names
function normalizeAmberPropertyName(header: string): string | null {
  const normalized = header.toLowerCase().trim();
  
  const propertyMap: Record<string, string> = {
    'timestep': 'timestep',
    'time': 'time',
    'potential_energy': 'potential_energy',
    'kinetic_energy': 'kinetic_energy',
    'translational_kinetic_energy': 'translational_kinetic_energy',
    'rotational_kinetic_energy': 'rotational_kinetic_energy',
    'temperature': 'temperature',
    'pressure': 'pressure',
    'pressure_xx': 'pressure_xx',
    'pressure_yy': 'pressure_yy',
    'pressure_zz': 'pressure_zz',
    'volume': 'volume',
    'lx': 'box_length_x',
    'ly': 'box_length_y',
    'lz': 'box_length_z',
    // Legacy mappings for traditional format
    'step': 'timestep',
    'temp': 'temperature',
    'press': 'pressure',
    'etot': 'total_energy',
    'ektot': 'kinetic_energy',
    'epot': 'potential_energy'
  };
  
  return propertyMap[normalized] || null;
}
  return {
    headers,
    data: allData,
    timeColumn: Math.max(0, timeColumn),
    properties,
  };
}