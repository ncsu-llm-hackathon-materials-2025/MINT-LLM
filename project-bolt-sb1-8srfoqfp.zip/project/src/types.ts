export type MDEngine = 'lammps' | 'gromacs' | 'amber';

export interface UploadedFile {
  id: string;
  name: string;
  size: number;
  content: string;
  type: string;
}

export interface AnalysisProperty {
  name: string;
  label: string;
  available: boolean;
  units?: string;
}

export interface AnalysisSuggestion {
  type: 'timeseries' | 'histogram' | 'drift' | 'blocks' | 'autocorr';
  properties: string[];
  description: string;
  parameters?: Record<string, any>;
}

export interface AnalysisPlan {
  properties: AnalysisProperty[];
  suggestions: AnalysisSuggestion[];
  selectedSuggestions: string[];
  parameters: {
    blockSize: number;
    smoothingWindow: number;
  };
}

export interface ParsedData {
  headers: string[];
  data: number[][];
  timeColumn: number;
  properties: Record<string, number>; // property name -> column index
}

export interface AnalysisResult {
  type: string;
  property: string;
  data: any;
  plot?: string; // base64 encoded plot
  statistics?: {
    mean: number;
    std: number;
    ci95: [number, number];
    drift?: {
      slope: number;
      slopeCI: [number, number];
      rSquared: number;
    };
  };
}