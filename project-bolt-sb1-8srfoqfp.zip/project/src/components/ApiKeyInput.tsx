import React, { useState } from 'react';
import { Key, ChevronLeft, ChevronRight, Shield, AlertCircle } from 'lucide-react';

interface ApiKeyInputProps {
  apiKey: string;
  onApiKeySubmit: (apiKey: string) => void;
  onBack: () => void;
}

export default function ApiKeyInput({ apiKey, onApiKeySubmit, onBack }: ApiKeyInputProps) {
  const [inputKey, setInputKey] = useState(apiKey);
  const [error, setError] = useState('');
  const [showKey, setShowKey] = useState(false);

  const validateApiKey = (key: string): boolean => {
    // More flexible OpenAI API key format validation
    const trimmedKey = key.trim();
    
    // Check if it starts with sk- and has reasonable length
    if (!trimmedKey.startsWith('sk-')) {
      return false;
    }
    
    // Check minimum length (OpenAI keys are typically 51+ characters)
    if (trimmedKey.length < 20) {
      return false;
    }
    
    // Check that it contains only valid characters (letters, numbers, hyphens, underscores)
    const validChars = /^sk-[a-zA-Z0-9\-_]+$/;
    return validChars.test(trimmedKey);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedKey = inputKey.trim();
    
    if (!trimmedKey) {
      setError('Please enter your OpenAI API key');
      return;
    }

    if (!validateApiKey(trimmedKey)) {
      setError('Invalid API key format. Please check your OpenAI API key.');
      return;
    }

    setError('');
    onApiKeySubmit(trimmedKey);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="p-4 bg-indigo-100 rounded-full">
            <Key className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Enter Your OpenAI API Key
        </h2>
        <p className="text-lg text-gray-600">
          We'll use this to power the AI analysis suggestions. Your key is stored in session memory only.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="apikey" className="block text-sm font-medium text-gray-700 mb-2">
              OpenAI API Key
            </label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                id="apikey"
                value={inputKey}
                onChange={(e) => {
                  setInputKey(e.target.value);
                  setError('');
                }}
                placeholder="sk-..."
                className={`
                  w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                  ${error ? 'border-red-300' : 'border-gray-300'}
                  font-mono text-sm
                `}
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
              >
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>
            {error && (
              <div className="flex items-center mt-2 text-red-600">
                <AlertCircle className="w-4 h-4 mr-2" />
                <span className="text-sm">{error}</span>
              </div>
            )}
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
              <div className="text-sm">
                <p className="text-blue-800 font-medium mb-1">Security & Privacy</p>
                <ul className="text-blue-700 space-y-1">
                  <li>• Your API key is stored in session memory only</li>
                  <li>• It's never saved to disk or sent to our servers</li>
                  <li>• Direct communication with OpenAI's API</li>
                  <li>• Key is cleared when you close the browser</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex justify-between">
            <button
              type="button"
              onClick={onBack}
              className="flex items-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Back
            </button>
            <button
              type="submit"
              disabled={!inputKey.trim()}
              className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              Continue
              <ChevronRight className="w-4 h-4 ml-2" />
            </button>
          </div>
        </form>
      </div>

      <div className="mt-8 text-center">
        <p className="text-sm text-gray-500">
          Don't have an OpenAI API key?{' '}
          <a
            href="https://platform.openai.com/account/api-keys"
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-600 hover:text-indigo-700 underline"
          >
            Get one here
          </a>
        </p>
      </div>
    </div>
  );
}