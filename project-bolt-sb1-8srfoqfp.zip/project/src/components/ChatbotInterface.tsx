import React, { useState } from 'react';
import { Bot, Send, ChevronLeft, Play, Settings } from 'lucide-react';
import { MDEngine, UploadedFile, AnalysisPlan, AnalysisProperty, AnalysisSuggestion } from '../types';
import { parseFiles } from '../utils/parsers';

interface ChatbotInterfaceProps {
  engine: MDEngine;
  uploadedFiles: UploadedFile[];
  apiKey: string;
  onAnalysisPlan: (plan: AnalysisPlan) => void;
  onBack: () => void;
}

export default function ChatbotInterface({ 
  engine, 
  uploadedFiles, 
  apiKey, 
  onAnalysisPlan, 
  onBack 
}: ChatbotInterfaceProps) {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [analysisPlan, setAnalysisPlan] = useState<AnalysisPlan | null>(null);
  const [selectedSuggestions, setSelectedSuggestions] = useState<string[]>([]);
  const [blockSize, setBlockSize] = useState(100);
  const [smoothingWindow, setSmoothingWindow] = useState(50);
  const [error, setError] = useState('');

  const generateAnalysisPlan = async () => {
    if (!query.trim()) return;

    setIsLoading(true);
    setError('');

    try {
      // Parse uploaded files to determine available properties
      const parsedData = parseFiles(uploadedFiles, engine);
      const availableProperties: AnalysisProperty[] = Object.entries(parsedData.properties).map(([name, index]) => ({
        name,
        label: name.charAt(0).toUpperCase() + name.slice(1),
        available: true,
        units: getUnitsForProperty(name, engine),
      }));

      // Prepare context for LLM
      const context = {
        engine,
        availableProperties: availableProperties.map(p => p.name),
        query: query.trim(),
        fileCount: uploadedFiles.length,
        dataPoints: parsedData.data.length,
      };

      // Call OpenAI API
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are MINT LLM, an expert in molecular dynamics analysis. Generate analysis suggestions based on available properties from ${engine.toUpperCase()} log files. 
              
Available properties: ${availableProperties.map(p => p.name).join(', ')}

Respond with a JSON object containing:
{
  "suggestions": [
    {
      "type": "timeseries|histogram|drift|blocks|autocorr",
      "properties": ["property1", "property2"],
      "description": "Clear description of the analysis",
      "parameters": {}
    }
  ]
}

Only suggest analyses for properties that are actually available in the data.`,
            },
            {
              role: 'user',
              content: `I have ${context.fileCount} ${engine} log files with ${context.dataPoints} data points. Available properties: ${context.availableProperties.join(', ')}. 

User request: ${context.query}

Please suggest appropriate analyses.`,
            },
          ],
          temperature: 0.7,
          max_tokens: 1000,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices[0]?.message?.content;

      if (!content) {
        throw new Error('No response from OpenAI API');
      }

      // Parse the JSON response
      const parsed = JSON.parse(content);
      const suggestions: AnalysisSuggestion[] = parsed.suggestions || [];

      // Filter suggestions to only include available properties
      const filteredSuggestions = suggestions.filter(s => 
        s.properties.every(prop => availableProperties.some(ap => ap.name === prop))
      );

      const plan: AnalysisPlan = {
        properties: availableProperties,
        suggestions: filteredSuggestions,
        selectedSuggestions: filteredSuggestions.map((_, index) => index.toString()),
        parameters: {
          blockSize,
          smoothingWindow,
        },
      };

      setAnalysisPlan(plan);
      setSelectedSuggestions(plan.selectedSuggestions);

    } catch (err) {
      console.error('Error generating analysis plan:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate analysis plan');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generateAnalysisPlan();
  };

  const toggleSuggestion = (index: string) => {
    setSelectedSuggestions(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const runAnalysis = () => {
    if (!analysisPlan) return;

    const finalPlan: AnalysisPlan = {
      ...analysisPlan,
      selectedSuggestions,
      parameters: {
        blockSize,
        smoothingWindow,
      },
    };

    onAnalysisPlan(finalPlan);
  };

  const getUnitsForProperty = (property: string, engine: MDEngine): string | undefined => {
    const units: Record<string, Record<string, string>> = {
      lammps: {
        'temp': 'K',
        'press': 'atm',
        'poteng': 'kcal/mol',
        'kineng': 'kcal/mol',
        'toteng': 'kcal/mol',
        'volume': 'Å³',
        'density': 'g/cm³',
      },
      gromacs: {
        'temperature': 'K',
        'pressure': 'bar',
        'potential': 'kJ/mol',
        'kinetic': 'kJ/mol',
        'total': 'kJ/mol',
        'volume': 'nm³',
        'density': 'kg/m³',
      },
      amber: {
        'temp': 'K',
        'press': 'atm',
        'epot': 'kcal/mol',
        'ektot': 'kcal/mol',
        'etot': 'kcal/mol',
        'volume': 'Å³',
        'density': 'g/cm³',
      },
    };

    return units[engine]?.[property.toLowerCase()];
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="p-4 bg-purple-100 rounded-full">
            <Bot className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Ask MINT
        </h2>
        <p className="text-lg text-gray-600">
          Describe what you'd like to analyze, and I'll suggest appropriate analyses for your {engine.toUpperCase()} data
        </p>
      </div>

      {/* Chat Input */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
        <form onSubmit={handleSubmit} className="p-6">
          <div className="flex space-x-4">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., 'check energy conservation and temperature stability' or 'analyze pressure fluctuations'"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!query.trim() || isLoading}
              className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Ask MINT
                </>
              )}
            </button>
          </div>

          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-800">{error}</p>
            </div>
          )}
        </form>
      </div>

      {/* Analysis Plan */}
      {analysisPlan && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Suggested Analysis Plan
            </h3>
            <p className="text-gray-600">
              Select the analyses you'd like to perform on your data:
            </p>
          </div>

          <div className="p-6 space-y-4">
            {analysisPlan.suggestions.map((suggestion, index) => (
              <div key={index} className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id={`suggestion-${index}`}
                  checked={selectedSuggestions.includes(index.toString())}
                  onChange={() => toggleSuggestion(index.toString())}
                  className="mt-1 w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                />
                <label htmlFor={`suggestion-${index}`} className="flex-1 cursor-pointer">
                  <div className="font-medium text-gray-900 mb-1">
                    {suggestion.type.charAt(0).toUpperCase() + suggestion.type.slice(1)} Analysis
                  </div>
                  <div className="text-gray-600 text-sm mb-2">
                    {suggestion.description}
                  </div>
                  <div className="text-xs text-gray-500">
                    Properties: {suggestion.properties.join(', ')}
                  </div>
                </label>
              </div>
            ))}
          </div>

          {/* Parameters */}
          <div className="border-t border-gray-200 p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Settings className="w-5 h-5 text-gray-600" />
              <h4 className="text-lg font-medium text-gray-900">Analysis Parameters</h4>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label htmlFor="blockSize" className="block text-sm font-medium text-gray-700 mb-2">
                  Block Size
                </label>
                <input
                  type="number"
                  id="blockSize"
                  value={blockSize}
                  onChange={(e) => setBlockSize(Number(e.target.value))}
                  min="10"
                  max="1000"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
                <p className="text-xs text-gray-500 mt-1">Number of data points per block</p>
              </div>
              
              <div>
                <label htmlFor="smoothingWindow" className="block text-sm font-medium text-gray-700 mb-2">
                  Smoothing Window
                </label>
                <input
                  type="number"
                  id="smoothingWindow"
                  value={smoothingWindow}
                  onChange={(e) => setSmoothingWindow(Number(e.target.value))}
                  min="1"
                  max="500"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
                <p className="text-xs text-gray-500 mt-1">Moving average window size</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex justify-between">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Back
        </button>
        
        {analysisPlan && (
          <button
            onClick={runAnalysis}
            disabled={selectedSuggestions.length === 0}
            className="flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            <Play className="w-4 h-4 mr-2" />
            Run Analysis
          </button>
        )}
      </div>
    </div>
  );
}