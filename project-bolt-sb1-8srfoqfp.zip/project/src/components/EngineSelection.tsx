import React from 'react';
import { ChevronRight, Database, Beaker, Zap } from 'lucide-react';
import { MDEngine } from '../types';

interface EngineSelectionProps {
  selectedEngine: MDEngine | null;
  onEngineSelect: (engine: MDEngine) => void;
}

const engines = [
  {
    id: 'lammps' as MDEngine,
    name: 'LAMMPS',
    icon: Zap,
    description: 'Large-scale Atomic/Molecular Massively Parallel Simulator',
    fileTypes: 'log.lammps files',
    color: 'from-red-500 to-orange-500',
    bgColor: 'bg-red-50 border-red-200',
    hoverColor: 'hover:bg-red-100',
  },
  {
    id: 'gromacs' as MDEngine,
    name: 'GROMACS',
    icon: Database,
    description: 'GROningen MAchine for Chemical Simulations',
    fileTypes: 'md.log and .xvg files',
    color: 'from-blue-500 to-indigo-500',
    bgColor: 'bg-blue-50 border-blue-200',
    hoverColor: 'hover:bg-blue-100',
  },
  {
    id: 'amber' as MDEngine,
    name: 'Amber',
    icon: Beaker,
    description: 'Assisted Model Building with Energy Refinement',
    fileTypes: 'mdout/mdinfo files',
    color: 'from-green-500 to-emerald-500',
    bgColor: 'bg-green-50 border-green-200',
    hoverColor: 'hover:bg-green-100',
  },
];

export default function EngineSelection({ selectedEngine, onEngineSelect }: EngineSelectionProps) {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Select Your MD Engine
        </h2>
        <p className="text-lg text-gray-600">
          Choose the molecular dynamics simulation engine used to generate your log files
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {engines.map((engine) => {
          const IconComponent = engine.icon;
          const isSelected = selectedEngine === engine.id;

          return (
            <button
              key={engine.id}
              onClick={() => onEngineSelect(engine.id)}
              className={`
                relative p-6 border-2 rounded-xl transition-all duration-200 text-left
                ${isSelected 
                  ? `${engine.bgColor} border-current ring-2 ring-offset-2 ring-current` 
                  : `border-gray-200 hover:border-gray-300 ${engine.hoverColor} bg-white`
                }
                group
              `}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${engine.color}`}>
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
                <ChevronRight 
                  className={`w-5 h-5 transition-all duration-200 ${
                    isSelected ? 'text-gray-700' : 'text-gray-400 group-hover:text-gray-600'
                  }`} 
                />
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {engine.name}
              </h3>
              
              <p className="text-gray-600 mb-3 text-sm leading-relaxed">
                {engine.description}
              </p>

              <div className="flex items-center text-sm text-gray-500">
                <span className="font-medium">Supports:</span>
                <span className="ml-2">{engine.fileTypes}</span>
              </div>

              {isSelected && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <div className="w-3 h-3 bg-white rounded-full" />
                </div>
              )}
            </button>
          );
        })}
      </div>

      {selectedEngine && (
        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-4">
            Great choice! You've selected {engines.find(e => e.id === selectedEngine)?.name}.
          </p>
        </div>
      )}
    </div>
  );
}