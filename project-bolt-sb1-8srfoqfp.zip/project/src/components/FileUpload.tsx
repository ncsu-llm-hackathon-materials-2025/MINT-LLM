import React, { useCallback, useState } from 'react';
import { Upload, File, X, CheckCircle, AlertTriangle, ChevronLeft, ChevronRight } from 'lucide-react';
import { MDEngine, UploadedFile } from '../types';

interface FileUploadProps {
  engine: MDEngine;
  uploadedFiles: UploadedFile[];
  onFilesUpdate: (files: UploadedFile[]) => void;
  onContinue: () => void;
  onBack: () => void;
}

const engineConfigs = {
  lammps: {
    name: 'LAMMPS',
    acceptedTypes: ['log.lammps', '.log'],
    description: 'Upload log.lammps files from your LAMMPS simulation',
    multiple: true,
  },
  gromacs: {
    name: 'GROMACS',
    acceptedTypes: ['md.log', '.xvg'],
    description: 'Upload md.log files and optional .xvg exports from gmx energy',
    multiple: true,
  },
  amber: {
    name: 'Amber',
    acceptedTypes: ['mdout', 'mdinfo', '.out'],
    description: 'Upload mdout or mdinfo files from your Amber simulation',
    multiple: true,
  },
};

export default function FileUpload({ engine, uploadedFiles, onFilesUpdate, onContinue, onBack }: FileUploadProps) {
  const [dragOver, setDragOver] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const config = engineConfigs[engine];

  const validateFile = (file: File): string | null => {
    const maxSize = 100 * 1024 * 1024; // 100MB
    
    if (file.size > maxSize) {
      return 'File size exceeds 100MB limit';
    }

    if (file.type && !file.type.startsWith('text/')) {
      const hasValidExtension = config.acceptedTypes.some(type => 
        file.name.toLowerCase().includes(type.toLowerCase())
      );
      if (!hasValidExtension) {
        return `File type not supported. Expected: ${config.acceptedTypes.join(', ')}`;
      }
    }

    return null;
  };

  const handleFiles = useCallback(async (files: FileList) => {
    const newFiles: UploadedFile[] = [];
    const newErrors: Record<string, string> = {};

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const error = validateFile(file);
      
      if (error) {
        newErrors[file.name] = error;
        continue;
      }

      try {
        const content = await file.text();
        const newFile: UploadedFile = {
          id: `${file.name}-${Date.now()}-${Math.random()}`,
          name: file.name,
          size: file.size,
          content,
          type: file.name.includes('.xvg') ? 'xvg' : 'log',
        };
        newFiles.push(newFile);
      } catch (err) {
        newErrors[file.name] = 'Failed to read file content';
      }
    }

    setErrors(newErrors);
    if (newFiles.length > 0) {
      onFilesUpdate([...uploadedFiles, ...newFiles]);
    }
  }, [uploadedFiles, onFilesUpdate, config]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files);
    }
  }, [handleFiles]);

  const removeFile = (fileId: string) => {
    onFilesUpdate(uploadedFiles.filter(f => f.id !== fileId));
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Upload {config.name} Files
        </h2>
        <p className="text-lg text-gray-600">
          {config.description}
        </p>
      </div>

      {/* Upload Area */}
      <div
        className={`
          relative border-2 border-dashed rounded-xl p-12 text-center transition-colors
          ${dragOver 
            ? 'border-indigo-500 bg-indigo-50' 
            : 'border-gray-300 hover:border-gray-400 bg-white'
          }
        `}
        onDrop={handleDrop}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
      >
        <input
          type="file"
          multiple={config.multiple}
          onChange={handleFileInput}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          accept=".log,.out,.xvg,text/*"
        />
        
        <Upload className={`w-12 h-12 mx-auto mb-4 ${dragOver ? 'text-indigo-500' : 'text-gray-400'}`} />
        
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Drop files here or click to browse
        </h3>
        
        <p className="text-gray-600 mb-4">
          Supported formats: {config.acceptedTypes.join(', ')}
        </p>
        
        <p className="text-sm text-gray-500">
          Maximum file size: 100MB per file
        </p>
      </div>

      {/* Error Messages */}
      {Object.keys(errors).length > 0 && (
        <div className="mt-6 space-y-2">
          {Object.entries(errors).map(([filename, error]) => (
            <div key={filename} className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-500 mr-3" />
              <div>
                <span className="font-medium text-red-800">{filename}:</span>
                <span className="text-red-700 ml-2">{error}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Uploaded Files List */}
      {uploadedFiles.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Uploaded Files ({uploadedFiles.length})
          </h3>
          
          <div className="space-y-3">
            {uploadedFiles.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <File className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{file.name}</p>
                    <p className="text-sm text-gray-500">
                      {formatFileSize(file.size)} • {file.type.toUpperCase()}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <button
                    onClick={() => removeFile(file.id)}
                    className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex justify-between mt-12">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Back
        </button>
        
        <button
          onClick={onContinue}
          disabled={uploadedFiles.length === 0}
          className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          Continue to Analysis
          <ChevronRight className="w-4 h-4 ml-2" />
        </button>
      </div>
    </div>
  );
}