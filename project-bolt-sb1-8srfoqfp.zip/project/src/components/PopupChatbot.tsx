import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Minimize2, Maximize2 } from 'lucide-react';
import { UploadedFile, ParsedData, MDEngine } from '../types';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

interface PopupChatbotProps {
  uploadedFiles: UploadedFile[];
  parsedData: ParsedData | null;
  engine: MDEngine | null;
  apiKey: string;
  onAddAnalysis?: (analysisType: string, property: string) => void;
  analysisMode?: boolean;
}

export default function PopupChatbot({ 
  uploadedFiles, 
  parsedData, 
  engine, 
  apiKey, 
  onAddAnalysis,
  analysisMode = false 
}: PopupChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: analysisMode 
        ? 'Hi! I\'m MINT, your analysis assistant. I can help you add new analyses, explain your results, or answer questions about your data. Try asking me to "add a histogram for temperature" or "create a drift analysis for pressure".'
        : 'Hi! I\'m MINT, your molecular dynamics analysis assistant. I can help you understand your data, explain trends, and suggest analyses. What would you like to know about your simulation?',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateDataSummary = (): string => {
    if (!parsedData || !engine) return 'No data available';

    const summary = {
      engine: engine.toUpperCase(),
      fileCount: uploadedFiles.length,
      dataPoints: parsedData.data.length,
      properties: Object.keys(parsedData.properties),
      timeRange: parsedData.data.length > 0 ? {
        start: parsedData.data[0][parsedData.timeColumn],
        end: parsedData.data[parsedData.data.length - 1][parsedData.timeColumn]
      } : null,
      sampleStats: Object.entries(parsedData.properties).reduce((acc, [prop, index]) => {
        const values = parsedData.data.map(row => row[index]).filter(v => !isNaN(v));
        if (values.length > 0) {
          const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
          const std = Math.sqrt(values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length);
          acc[prop] = { mean: mean.toFixed(4), std: std.toFixed(4), count: values.length };
        }
        return acc;
      }, {} as Record<string, any>)
    };

    return JSON.stringify(summary, null, 2);
  };

  const parseAnalysisRequest = (message: string): { type: string; property: string } | null => {
    const lowerMessage = message.toLowerCase();
    
    // Extract analysis type
    let analysisType = '';
    if (lowerMessage.includes('histogram')) analysisType = 'histogram';
    else if (lowerMessage.includes('timeseries') || lowerMessage.includes('time series')) analysisType = 'timeseries';
    else if (lowerMessage.includes('drift')) analysisType = 'drift';
    else if (lowerMessage.includes('block')) analysisType = 'blocks';
    else if (lowerMessage.includes('autocorr') || lowerMessage.includes('correlation')) analysisType = 'autocorr';
    
    if (!analysisType) return null;
    
    // Extract property
    const availableProperties = parsedData ? Object.keys(parsedData.properties) : [];
    const property = availableProperties.find(prop => 
      lowerMessage.includes(prop.toLowerCase()) || 
      lowerMessage.includes(prop.replace(/_/g, ' ').toLowerCase())
    );
    
    return property ? { type: analysisType, property } : null;
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || isLoading || !apiKey) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    // Check if this is an analysis request in analysis mode
    if (analysisMode && onAddAnalysis) {
      const analysisRequest = parseAnalysisRequest(userMessage.content);
      if (analysisRequest) {
        onAddAnalysis(analysisRequest.type, analysisRequest.property);
        const confirmMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: 'bot',
          content: `I've added a ${analysisRequest.type} analysis for ${analysisRequest.property.replace(/_/g, ' ')} to your results page.`,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, confirmMessage]);
        setIsLoading(false);
        return;
      }
    }

    try {
      const dataSummary = generateDataSummary();
      
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are MINT, an expert molecular dynamics analysis assistant. You help users understand their simulation data, explain trends, and suggest analyses.${
                analysisMode ? `

ANALYSIS MODE: You can add new analyses to the current results page. When users request specific analyses (like "add histogram for temperature"), respond that you've added it. Available analysis types: histogram, timeseries, drift, blocks, autocorr.` : ''
              }

Current data context:
${dataSummary}

Guidelines:
- Be conversational and helpful
- Explain concepts clearly for both beginners and experts
- Suggest specific analyses when relevant
- Point out interesting trends or potential issues in the data
- Keep responses concise but informative
- If asked about specific properties, reference the actual values from the data${
                analysisMode ? '\n- In analysis mode, you can add new plots by saying things like "add histogram for temperature"' : ''
              }
- Help interpret statistical measures and their significance in MD simulations`,
            },
            {
              role: 'user',
              content: userMessage.content,
            },
          ],
          temperature: 0.7,
          max_tokens: 500,
        }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      const botResponse = data.choices[0]?.message?.content || 'Sorry, I couldn\'t process that request.';

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: botResponse,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Chatbot error:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: 'Sorry, I encountered an error processing your request. Please check your API key and try again.',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-purple-600 hover:bg-purple-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center z-50 group"
      >
        <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${
      isMinimized ? 'w-80 h-12' : 'w-96 h-[500px]'
    }`}>
      <div className="bg-white rounded-lg shadow-2xl border border-gray-200 h-full flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-purple-600 text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold">MINT Assistant</h3>
              <p className="text-xs text-purple-200">
                {analysisMode ? 'Analysis Mode - Add/Remove plots' : parsedData ? `${parsedData.data.length} data points loaded` : 'Ready to help'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-1 hover:bg-purple-500 rounded transition-colors"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-purple-500 rounded transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex items-start space-x-2 max-w-[80%] ${
                    message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                  }`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.type === 'user' 
                        ? 'bg-purple-600 text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {message.type === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                    </div>
                    <div className={`p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-purple-600 text-white'
                        : 'bg-white text-gray-800 border border-gray-200'
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      <p className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-purple-200' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex items-start space-x-2">
                    <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                      <Bot className="w-4 h-4 text-gray-600" />
                    </div>
                    <div className="bg-white p-3 rounded-lg border border-gray-200">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-200 bg-white">
              {!apiKey ? (
                <div className="text-center text-sm text-gray-500 py-2">
                  Please enter your OpenAI API key to use the chatbot
                </div>
              ) : (
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={analysisMode ? "Add analyses: 'histogram for temperature', 'drift for pressure'..." : "Ask about your simulation data..."}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-sm"
                    disabled={isLoading}
                  />
                  <button
                    onClick={sendMessage}
                    disabled={!inputMessage.trim() || isLoading}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center"
                  >
                    {analysisMode ? <Plus className="w-4 h-4" /> : <Send className="w-4 h-4" />}
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}