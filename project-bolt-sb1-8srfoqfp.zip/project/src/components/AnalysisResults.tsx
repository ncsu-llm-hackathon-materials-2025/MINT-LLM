import React, { useEffect, useState } from 'react';
import { BarChart3, Download, ChevronLeft, RotateCcw, TrendingUp, X, Plus } from 'lucide-react';
import { MDEngine, UploadedFile, AnalysisPlan, AnalysisResult } from '../types';
import { parseFiles } from '../utils/parsers';
import { performAnalysis } from '../utils/analysis';
import IntegratedChatbot from './IntegratedChatbot';

interface AnalysisResultsProps {
  engine: MDEngine;
  uploadedFiles: UploadedFile[];
  analysisPlan: AnalysisPlan;
  apiKey: string;
  onBack: () => void;
  onNewAnalysis: () => void;
}

export default function AnalysisResults({ 
  engine, 
  uploadedFiles, 
  analysisPlan, 
  apiKey,
  onBack, 
  onNewAnalysis 
}: AnalysisResultsProps) {
  const [results, setResults] = useState<AnalysisResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [parsedData, setParsedData] = useState<any>(null);

  useEffect(() => {
    runAnalysis();
  }, []);

  // Filter out timestep vs timestep plots
  const isValidPlot = (result: AnalysisResult): boolean => {
    const property = result.property.toLowerCase();
    return !['step', 'timestep', 'time'].includes(property);
  };

  const addNewAnalysis = async (analysisType: string, property: string) => {
    if (!parsedData) return;

    try {
      const result = await performAnalysis(
        analysisType,
        property,
        parsedData,
        analysisPlan.parameters
      );
      
      if (result && isValidPlot(result)) {
        setResults(prev => [...prev, result]);
      }
    } catch (err) {
      console.error('Error adding new analysis:', err);
    }
  };

  const removeAnalysis = (index: number) => {
    setResults(prev => prev.filter((_, i) => i !== index));
  };

  const runAnalysis = async () => {
    setLoading(true);
    setError('');

    try {
      // Parse the uploaded files
      const parsedData = parseFiles(uploadedFiles, engine);
      setParsedData(parsedData);
      
      // Perform selected analyses
      const analysisResults: AnalysisResult[] = [];
      
      for (const suggestionIndex of analysisPlan.selectedSuggestions) {
        const suggestion = analysisPlan.suggestions[parseInt(suggestionIndex)];
        if (suggestion) {
          for (const property of suggestion.properties) {
            const result = await performAnalysis(
              suggestion.type,
              property,
              parsedData,
              analysisPlan.parameters
            );
            if (result && isValidPlot(result)) {
              analysisResults.push(result);
            }
          }
        }
      }

      setResults(analysisResults);
    } catch (err) {
      console.error('Analysis error:', err);
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const downloadReport = () => {
    const reportData = {
      engine: engine.toUpperCase(),
      files: uploadedFiles.map(f => ({ name: f.name, size: f.size })),
      analysisPlan,
      results,
      timestamp: new Date().toISOString(),
    };

    const htmlContent = generateHTMLReport(reportData);
    
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mint-analysis-report-${Date.now()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const generateHTMLReport = (data: any) => {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>MINT Analysis Report</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 40px; }
        .header { border-bottom: 2px solid #e5e7eb; padding-bottom: 20px; margin-bottom: 30px; }
        .result { margin-bottom: 30px; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
        .plot { text-align: center; margin: 20px 0; }
        img { max-width: 100%; height: auto; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #e5e7eb; padding: 8px; text-align: left; }
        th { background-color: #f9fafb; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>MINT LLM Analysis Report</h1>
        <p><strong>Engine:</strong> ${data.engine}</p>
        <p><strong>Generated:</strong> ${new Date(data.timestamp).toLocaleString()}</p>
        <p><strong>Files analyzed:</strong> ${data.files.map((f: any) => f.name).join(', ')}</p>
      </div>
      
      ${data.results.map((result: AnalysisResult) => `
        <div class="result">
          <h2>${result.type.charAt(0).toUpperCase() + result.type.slice(1)} Analysis - ${result.property}</h2>
          ${result.plot ? `<div class="plot"><img src="${result.plot}" alt="${result.type} plot for ${result.property}"></div>` : ''}
          ${result.statistics ? `
            <h3>Statistics</h3>
            <table>
              <tr><th>Metric</th><th>Value</th></tr>
              <tr><td>Mean</td><td>${result.statistics.mean.toFixed(4)}</td></tr>
              <tr><td>Standard Deviation</td><td>${result.statistics.std.toFixed(4)}</td></tr>
              <tr><td>95% Confidence Interval</td><td>[${result.statistics.ci95[0].toFixed(4)}, ${result.statistics.ci95[1].toFixed(4)}]</td></tr>
              ${result.statistics.drift ? `
                <tr><td>Linear Drift Slope</td><td>${result.statistics.drift.slope.toFixed(6)}</td></tr>
                <tr><td>R²</td><td>${result.statistics.drift.rSquared.toFixed(4)}</td></tr>
              ` : ''}
            </table>
          ` : ''}
        </div>
      `).join('')}
    </body>
    </html>
    `;
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto text-center py-16">
        <div className="animate-spin w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto mb-4"></div>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Analyzing Your Data</h2>
        <p className="text-gray-600">This may take a few moments...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto text-center py-16">
        <div className="bg-red-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
          <BarChart3 className="w-8 h-8 text-red-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Analysis Failed</h2>
        <p className="text-gray-600 mb-6">{error}</p>
        <button
          onClick={onBack}
          className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-screen">
        {/* Main Results Panel */}
        <div className="lg:col-span-2 overflow-y-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                Analysis Results
              </h2>
              <p className="text-gray-600">
                {results.length} analyses completed for {engine.toUpperCase()} data
              </p>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={downloadReport}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </button>
            </div>
          </div>

          {/* Results Grid */}
          <div className="space-y-8 pb-8">
            {results.filter(isValidPlot).map((result, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-6 border-b border-gray-200 bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">
                        {result.type.charAt(0).toUpperCase() + result.type.slice(1)} Analysis
                      </h3>
                      <p className="text-gray-600">Property: {result.property}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-6 h-6 text-indigo-600" />
                      <button
                        onClick={() => removeAnalysis(index)}
                        className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                        title="Remove this analysis"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  {/* Plot */}
                  {result.plot && (
                    <div className="mb-6 text-center">
                      <img 
                        src={result.plot} 
                        alt={`${result.type} analysis for ${result.property}`}
                        className="max-w-full h-auto rounded-lg shadow-sm border border-gray-200"
                      />
                    </div>
                  )}

                  {/* Statistics */}
                  {result.statistics && (
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Basic Statistics</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Mean:</span>
                            <span className="font-mono">{result.statistics.mean.toFixed(4)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Std Dev:</span>
                            <span className="font-mono">{result.statistics.std.toFixed(4)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">95% CI:</span>
                            <span className="font-mono">
                              [{result.statistics.ci95[0].toFixed(4)}, {result.statistics.ci95[1].toFixed(4)}]
                            </span>
                          </div>
                        </div>
                      </div>

                      {result.statistics.drift && (
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3">Drift Analysis</h4>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Slope:</span>
                              <span className="font-mono">{result.statistics.drift.slope.toFixed(6)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">R²:</span>
                              <span className="font-mono">{result.statistics.drift.rSquared.toFixed(4)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Slope CI:</span>
                              <span className="font-mono text-xs">
                                [{result.statistics.drift.slopeCI[0].toFixed(6)}, {result.statistics.drift.slopeCI[1].toFixed(6)}]
                              </span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex justify-between py-6 border-t border-gray-200 bg-white sticky bottom-0">
            <button
              onClick={onBack}
              className="flex items-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Back to Chat
            </button>
            
            <button
              onClick={onNewAnalysis}
              className="flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              New Analysis
            </button>
          </div>
        </div>

        {/* Integrated Chatbot Panel */}
        <div className="lg:col-span-1">
          <IntegratedChatbot
            uploadedFiles={uploadedFiles}
            parsedData={parsedData}
            engine={engine}
            apiKey={apiKey}
            onAddAnalysis={addNewAnalysis}
            analysisMode={true}
          />
        </div>
      </div>
    </div>
  );
}